-- Két Sắt Việt — PostgreSQL 16 — v2.0 (dự thảo triển khai, CHƯA kiểm toán)
-- Nguyên tắc: chỉ lưu bản mã + metadata tối thiểu; mọi truy vấn của API chạy bằng role không phải owner,
-- không BYPASSRLS, và luôn đặt  SET LOCAL app.user_id = '<uuid>'  trong transaction.

-- ───────────── Roles ─────────────
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'ksv_app')    THEN CREATE ROLE ksv_app    NOLOGIN NOBYPASSRLS; END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'ksv_auth')   THEN CREATE ROLE ksv_auth   NOLOGIN NOBYPASSRLS; END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'ksv_worker') THEN CREATE ROLE ksv_worker NOLOGIN NOBYPASSRLS; END IF;
END $$;

CREATE OR REPLACE FUNCTION app_user_id() RETURNS uuid
LANGUAGE sql STABLE AS $$ SELECT nullif(current_setting('app.user_id', true), '')::uuid $$;

-- ───────────── Tài khoản & xác thực ─────────────
CREATE TABLE users (
  id                uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email_normalized  text NOT NULL UNIQUE CHECK (email_normalized = lower(email_normalized)),
  email_verified_at timestamptz,
  opaque_record     bytea NOT NULL,               -- bản ghi đăng ký OPAQUE (RFC 9807); không chứa mật khẩu
  kdf_params        jsonb NOT NULL,               -- {alg:"argon2id", m_kib, t, p, salt_b64, version}
  wrapped_root_key  bytea NOT NULL,               -- rootKey (ARK) bọc bởi KEK = f(mật khẩu chính, Secret Key)
  key_version       int   NOT NULL DEFAULT 1,
  status            text  NOT NULL DEFAULT 'active'
                    CHECK (status IN ('active','locked','pending_deletion','disabled')),
  created_at        timestamptz NOT NULL DEFAULT now(),
  updated_at        timestamptz NOT NULL DEFAULT now(),
  disabled_at       timestamptz
);

CREATE TABLE user_mfa (
  id                uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id           uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  kind              text NOT NULL CHECK (kind IN ('totp','webauthn')),
  label             text CHECK (char_length(label) <= 64),
  secret_ciphertext bytea,                        -- TOTP secret, mã hóa phong bì bằng KMS phía server (KHÔNG phải khóa két)
  credential_id     bytea,                        -- WebAuthn
  public_key        bytea,                        -- WebAuthn
  sign_count        bigint,
  confirmed_at      timestamptz,
  created_at        timestamptz NOT NULL DEFAULT now(),
  last_used_at      timestamptz,
  revoked_at        timestamptz
);

CREATE TABLE mfa_backup_codes (
  id        uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id   uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  code_hash bytea NOT NULL,                       -- HMAC-SHA256 với pepper trong KMS
  used_at   timestamptz,
  UNIQUE (user_id, code_hash)
);

CREATE TABLE email_challenges (                    -- OTP nhập trong ứng dụng; không dựa vào link
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email_normalized text NOT NULL,
  user_id        uuid REFERENCES users(id) ON DELETE CASCADE,
  purpose        text NOT NULL CHECK (purpose IN ('register','login_new_device','recovery','change_email','delete_account','mfa_reset')),
  code_hmac      bytea NOT NULL,                  -- HMAC-SHA256(pepper_KMS, code || id); không lưu mã rõ
  client_nonce_hash bytea NOT NULL,               -- gắn OTP với phiên khởi tạo của đúng client
  attempts       smallint NOT NULL DEFAULT 0 CHECK (attempts BETWEEN 0 AND 5),
  created_at     timestamptz NOT NULL DEFAULT now(),
  expires_at     timestamptz NOT NULL,
  consumed_at    timestamptz
);
CREATE INDEX ix_email_challenges_email ON email_challenges (email_normalized, created_at DESC);

-- ───────────── Thiết bị, phiên, phê duyệt ─────────────
CREATE TABLE devices (
  id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id          uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  name             text NOT NULL CHECK (char_length(name) BETWEEN 1 AND 64),
  platform         text NOT NULL CHECK (platform IN ('web','android','ios')),
  sign_public_key  bytea NOT NULL,                -- ECDSA P-256 (ký yêu cầu nhạy cảm; Secure Enclave/Keystore/WebCrypto đều hỗ trợ)
  box_public_key   bytea NOT NULL,                -- X25519 (nhận Secret Key mã hóa từ thiết bị tin cậy)
  status           text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','active','revoked')),
  approved_by_device_id uuid REFERENCES devices(id),
  approved_at      timestamptz,
  created_at       timestamptz NOT NULL DEFAULT now(),
  last_seen_at     timestamptz,
  revoked_at       timestamptz,
  revoked_reason   text CHECK (revoked_reason IN ('user','password_change','recovery','compromise_suspected','admin')),
  UNIQUE (id, user_id)
);
CREATE INDEX ix_devices_user ON devices (user_id) WHERE status <> 'revoked';

CREATE TABLE device_approvals (
  id                 uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id            uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  new_device_id      uuid NOT NULL,
  approver_device_id uuid,
  method             text NOT NULL CHECK (method IN ('trusted_device','delay')),
  status             text NOT NULL DEFAULT 'waiting' CHECK (status IN ('waiting','approved','rejected','expired','cancelled')),
  request_nonce      bytea NOT NULL CHECK (octet_length(request_nonce) = 32),
  approver_signature bytea,                       -- chữ ký P-256 của thiết bị phê duyệt trên (approvalId || khóa công khai thiết bị mới || nonce)
  sealed_secret_key  bytea,                       -- Secret Key được mã hóa (sealed box) tới box_public_key của thiết bị mới
  not_before         timestamptz NOT NULL DEFAULT now(),  -- với method='delay': thời điểm sớm nhất được duyệt
  expires_at         timestamptz NOT NULL,
  created_at         timestamptz NOT NULL DEFAULT now(),
  decided_at         timestamptz,
  FOREIGN KEY (new_device_id, user_id)      REFERENCES devices (id, user_id) ON DELETE CASCADE,
  FOREIGN KEY (approver_device_id, user_id) REFERENCES devices (id, user_id)
);

CREATE TABLE sessions (
  id                 uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id            uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  device_id          uuid NOT NULL,
  refresh_family_id  uuid NOT NULL,               -- phát hiện tái sử dụng refresh token cũ => thu hồi cả họ
  refresh_token_hash bytea NOT NULL UNIQUE,       -- SHA-256 của token (token có entropy cao nên không cần KDF chậm)
  amr                text[] NOT NULL DEFAULT '{}',-- phương thức đã dùng: opaque, totp, webauthn, device_approval
  auth_time          timestamptz NOT NULL,
  issued_at          timestamptz NOT NULL DEFAULT now(),
  expires_at         timestamptz NOT NULL,
  absolute_expires_at timestamptz NOT NULL,
  last_used_at       timestamptz,
  revoked_at         timestamptz,
  revoke_reason      text,
  reuse_detected_at  timestamptz,
  ip_hmac            bytea,
  ua_family          text,
  FOREIGN KEY (device_id, user_id) REFERENCES devices (id, user_id) ON DELETE CASCADE
);
CREATE INDEX ix_sessions_user ON sessions (user_id) WHERE revoked_at IS NULL;
CREATE INDEX ix_sessions_family ON sessions (refresh_family_id);

-- ───────────── Két sắt & mục ─────────────
CREATE TABLE vaults (
  id                uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id           uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  wrapped_vault_key bytea NOT NULL,               -- vaultKey bọc bởi khóa dẫn xuất từ rootKey
  key_version       int   NOT NULL DEFAULT 1,
  encrypted_name    bytea,
  change_seq        bigint NOT NULL DEFAULT 0,    -- bộ đếm thay đổi đơn điệu theo két (dùng làm cursor đồng bộ)
  created_at        timestamptz NOT NULL DEFAULT now(),
  deleted_at        timestamptz,
  UNIQUE (id, user_id)
);

CREATE TABLE vault_items (
  id               uuid PRIMARY KEY,              -- client tạo (UUIDv4) để hỗ trợ tạo ngoại tuyến
  vault_id         uuid NOT NULL,
  user_id          uuid NOT NULL,                 -- khử chuẩn hóa để RLS không cần join
  revision         bigint NOT NULL DEFAULT 1 CHECK (revision > 0),
  change_seq       bigint NOT NULL DEFAULT 0,     -- trigger gán
  schema_version   int NOT NULL,
  aad_version      int NOT NULL,
  key_version      int NOT NULL,                  -- phiên bản vaultKey đã bọc itemKey
  wrapped_item_key bytea NOT NULL CHECK (octet_length(wrapped_item_key) = 72),  -- nonce24 || ct32 || tag16
  nonce            bytea NOT NULL CHECK (octet_length(nonce) = 24),            -- XChaCha20-Poly1305
  ciphertext       bytea NOT NULL CHECK (octet_length(ciphertext) BETWEEN 17 AND 262160), -- ≤ 256 KiB + tag
  deleted_at       timestamptz,
  created_at       timestamptz NOT NULL DEFAULT now(),
  updated_at       timestamptz NOT NULL DEFAULT now(),
  FOREIGN KEY (vault_id, user_id) REFERENCES vaults (id, user_id) ON DELETE CASCADE,
  UNIQUE (vault_id, change_seq) DEFERRABLE INITIALLY DEFERRED
);
CREATE INDEX ix_items_changes ON vault_items (vault_id, change_seq);

-- Gán change_seq và revision trong cùng transaction; khóa hàng vaults tuần tự hóa ghi theo két
-- (đủ cho két cá nhân), nên change_seq commit đúng thứ tự và không có "lỗ" cho cursor.
CREATE OR REPLACE FUNCTION next_change_seq(p_vault uuid) RETURNS bigint
LANGUAGE sql AS $$ UPDATE vaults SET change_seq = change_seq + 1 WHERE id = p_vault RETURNING change_seq $$;

CREATE OR REPLACE FUNCTION trg_items_before_write() RETURNS trigger
LANGUAGE plpgsql AS $$
BEGIN
  NEW.change_seq := next_change_seq(NEW.vault_id);
  NEW.updated_at := now();
  IF TG_OP = 'UPDATE' THEN
    NEW.revision := OLD.revision + 1;             -- CAS thực hiện ở API: UPDATE ... WHERE id=$1 AND revision=$2
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER items_before_write BEFORE INSERT OR UPDATE ON vault_items
  FOR EACH ROW EXECUTE FUNCTION trg_items_before_write();

CREATE TABLE item_revisions (                      -- giữ ≤ 10 bản hoặc 90 ngày (worker dọn)
  id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  item_id          uuid NOT NULL REFERENCES vault_items(id) ON DELETE CASCADE,
  user_id          uuid NOT NULL,
  revision         bigint NOT NULL,
  key_version      int NOT NULL,
  wrapped_item_key bytea NOT NULL,
  nonce            bytea NOT NULL,
  ciphertext       bytea NOT NULL,
  created_at       timestamptz NOT NULL DEFAULT now(),
  UNIQUE (item_id, revision)
);

CREATE TABLE attachments (
  id                uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  item_id           uuid NOT NULL REFERENCES vault_items(id) ON DELETE CASCADE,
  vault_id          uuid NOT NULL,
  user_id           uuid NOT NULL,
  storage_key       text NOT NULL UNIQUE,         -- khóa đối tượng ngẫu nhiên, không chứa tên tệp
  wrapped_file_key  bytea NOT NULL,
  encrypted_metadata bytea NOT NULL,              -- tên tệp, loại MIME nằm trong bản mã
  chunk_size        int NOT NULL DEFAULT 1048576,
  ciphertext_size   bigint NOT NULL CHECK (ciphertext_size BETWEEN 0 AND 10485760 + 1048576),
  ciphertext_sha256 bytea CHECK (octet_length(ciphertext_sha256) = 32),
  state             text NOT NULL DEFAULT 'pending' CHECK (state IN ('pending','uploaded','deleted')),
  created_at        timestamptz NOT NULL DEFAULT now(),
  uploaded_at       timestamptz
);

-- ───────────── Khôi phục & xóa tài khoản ─────────────
CREATE TABLE recovery_kits (
  id                        uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id                   uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  recovery_wrapped_root_key bytea NOT NULL,       -- rootKey bọc bởi Recovery Key (256 bit, chỉ người dùng giữ)
  kit_version               int NOT NULL,
  created_at                timestamptz NOT NULL DEFAULT now(),
  revoked_at                timestamptz
);
CREATE UNIQUE INDEX ux_recovery_kits_active ON recovery_kits (user_id) WHERE revoked_at IS NULL;

CREATE TABLE recovery_sessions (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id      uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  kind         text NOT NULL CHECK (kind IN ('master_password','account_reset','mfa_reset')),
  token_hash   bytea NOT NULL UNIQUE,             -- bí mật của phiên khôi phục (băm)
  status       text NOT NULL DEFAULT 'waiting' CHECK (status IN ('waiting','ready','completed','cancelled','expired')),
  not_before   timestamptz NOT NULL,              -- 24 giờ (master_password) / 72 giờ (account_reset, mfa_reset)
  expires_at   timestamptz NOT NULL,
  cancelled_by_device_id uuid,
  created_at   timestamptz NOT NULL DEFAULT now(),
  completed_at timestamptz
);

CREATE TABLE account_deletions (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id      uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  requested_at timestamptz NOT NULL DEFAULT now(),
  effective_at timestamptz NOT NULL,              -- mặc định +7 ngày, có thể hủy
  status       text NOT NULL DEFAULT 'scheduled' CHECK (status IN ('scheduled','cancelled','done'))
);

-- ───────────── Hạ tầng API ─────────────
CREATE TABLE idempotency_keys (
  user_id      uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  key          text NOT NULL CHECK (char_length(key) BETWEEN 16 AND 128),
  request_hash bytea NOT NULL,
  status_code  int,
  response_ref jsonb,                             -- tham chiếu kết quả (id, revision), không lưu bản mã
  created_at   timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (user_id, key)
);

CREATE TABLE audit_events (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id     uuid REFERENCES users(id) ON DELETE SET NULL,
  event_type  text NOT NULL CHECK (event_type IN (
    'register','login_success','login_failed','mfa_success','mfa_failed','email_challenge_sent',
    'device_approval_requested','device_approved','device_rejected','device_revoked','session_revoked',
    'refresh_reuse_detected','password_changed','recovery_started','recovery_cancelled','recovery_completed',
    'recovery_kit_rotated','mfa_changed','account_deletion_requested','account_deletion_cancelled')),
  device_id   uuid,
  occurred_at timestamptz NOT NULL DEFAULT now(),
  ip_hmac     bytea,                              -- HMAC-SHA256 với khóa xoay vòng trong KMS (băm không khóa của IPv4 có thể bị đảo ngược)
  ip_hmac_key_id smallint,
  ua_family   text,
  details     jsonb NOT NULL DEFAULT '{}'::jsonb
              CHECK (jsonb_typeof(details) = 'object' AND pg_column_size(details) <= 1024)
);
CREATE INDEX ix_audit_user_time ON audit_events (user_id, occurred_at DESC);

-- ───────────── Row-Level Security ─────────────
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE users FORCE  ROW LEVEL SECURITY;
CREATE POLICY users_self  ON users FOR SELECT TO ksv_app  USING (id = app_user_id());
CREATE POLICY users_auth  ON users FOR ALL    TO ksv_auth USING (true) WITH CHECK (true);

DO $$
DECLARE t text;
BEGIN
  FOREACH t IN ARRAY ARRAY['user_mfa','mfa_backup_codes','devices','device_approvals','sessions','vaults','vault_items',
                           'item_revisions','attachments','recovery_kits','recovery_sessions','account_deletions',
                           'idempotency_keys','audit_events'] LOOP
    EXECUTE format('ALTER TABLE %I ENABLE ROW LEVEL SECURITY', t);
    EXECUTE format('ALTER TABLE %I FORCE ROW LEVEL SECURITY', t);
    EXECUTE format('CREATE POLICY %I ON %I FOR ALL TO ksv_app USING (user_id = app_user_id()) WITH CHECK (user_id = app_user_id())', t || '_owner', t);
  END LOOP;
  -- Dịch vụ xác thực cần thấy mọi hàng của các bảng liên quan đăng nhập/khôi phục
  FOREACH t IN ARRAY ARRAY['user_mfa','mfa_backup_codes','devices','device_approvals','sessions','recovery_kits',
                           'recovery_sessions','account_deletions','audit_events'] LOOP
    EXECUTE format('CREATE POLICY %I ON %I FOR ALL TO ksv_auth USING (true) WITH CHECK (true)', t || '_auth', t);
  END LOOP;
END $$;

ALTER TABLE email_challenges ENABLE ROW LEVEL SECURITY;
ALTER TABLE email_challenges FORCE  ROW LEVEL SECURITY;
CREATE POLICY email_challenges_auth ON email_challenges FOR ALL TO ksv_auth USING (true) WITH CHECK (true);

-- Worker dọn dẹp: chỉ xóa dữ liệu hết hạn, không đọc bản mã
CREATE POLICY email_challenges_worker ON email_challenges FOR ALL TO ksv_worker USING (expires_at < now() - interval '1 day');
CREATE POLICY idem_worker ON idempotency_keys FOR ALL TO ksv_worker USING (created_at < now() - interval '24 hours');
CREATE POLICY audit_worker ON audit_events FOR ALL TO ksv_worker USING (occurred_at < now() - interval '180 days');
CREATE POLICY revisions_worker ON item_revisions FOR ALL TO ksv_worker USING (created_at < now() - interval '90 days');

-- ───────────── Quyền ─────────────
REVOKE ALL ON ALL TABLES IN SCHEMA public FROM PUBLIC;
GRANT SELECT, INSERT, UPDATE, DELETE ON vaults, vault_items, item_revisions, attachments, idempotency_keys TO ksv_app;
GRANT SELECT ON users, devices, sessions, recovery_kits, account_deletions TO ksv_app;
GRANT SELECT, INSERT ON audit_events TO ksv_app;            -- không UPDATE/DELETE: nhật ký chỉ ghi thêm
GRANT EXECUTE ON FUNCTION next_change_seq(uuid), app_user_id() TO ksv_app;
GRANT SELECT, INSERT, UPDATE, DELETE ON users, user_mfa, mfa_backup_codes, email_challenges, devices, device_approvals,
      sessions, recovery_kits, recovery_sessions, account_deletions TO ksv_auth;
GRANT SELECT, INSERT ON audit_events TO ksv_auth;
-- Worker chỉ được xóa; SELECT giới hạn ở cột cần cho điều kiện WHERE (không đọc bản mã)
GRANT DELETE ON email_challenges, idempotency_keys, audit_events, item_revisions TO ksv_worker;
GRANT SELECT (id, expires_at)  ON email_challenges TO ksv_worker;
GRANT SELECT (user_id, created_at) ON idempotency_keys TO ksv_worker;
GRANT SELECT (id, occurred_at) ON audit_events TO ksv_worker;
GRANT SELECT (id, created_at)  ON item_revisions TO ksv_worker;
-- Không role ứng dụng nào được TRUNCATE/DDL. Migration chạy bằng role riêng, có phê duyệt trong CI.
