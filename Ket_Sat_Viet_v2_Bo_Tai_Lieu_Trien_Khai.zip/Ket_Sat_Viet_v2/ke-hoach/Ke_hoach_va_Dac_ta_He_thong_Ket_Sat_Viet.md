# Kế hoạch triển khai và đặc tả hệ thống (PRD + SRS) — Két Sắt Việt

Phiên bản 2.0 | Cập nhật 26/11/2026 | Trạng thái: **Dự thảo để phê duyệt; thay thế v1.0 (28/10/2026)**

Sản phẩm: Web + Android + iPhone; đồng bộ dữ liệu mã hóa đầu cuối; giao diện hoàn toàn bằng tiếng Việt.
Tài liệu đi kèm: Technical Design, ADR, Threat Model, Kiểm soát chuỗi cung ứng, Runbook, Backlog triển khai.

---

## 1. Tóm tắt điều hành

Két sắt số cá nhân lưu thông tin đăng nhập, thông tin nhận diện tài khoản ngân hàng (không lưu thông tin xác thực giao dịch), giấy tờ, ghi chú và tệp đính kèm. Dữ liệu được mã hóa trên thiết bị trước khi đồng bộ; máy chủ chỉ xử lý bản mã và metadata tối thiểu.

**Điểm thay đổi so với v1 (chi tiết ở `00-danh-gia/`):**

1. Bổ sung **Secret Key** vào khóa dẫn xuất để lộ DB không đủ để dò mật khẩu chính offline.
2. Chốt xác thực **OPAQUE** thay cho placeholder; OTP trong ứng dụng thay cho liên kết email.
3. **Phê duyệt thiết bị bằng QR + chữ ký**, chống thay khóa công khai nếu máy chủ bị chiếm.
4. **Chuỗi cung ứng và CI/CD trở thành yêu cầu bắt buộc** (bài học từ sự cố 1Password tháng 11/2026), kèm giám sát toàn vẹn mã web.
5. Sửa lỗi thiết kế đồng bộ (cursor theo `change_seq`), thống nhất hợp đồng API, thêm RLS và idempotency.
6. Thêm runbook sự cố, mốc pháp lý, và lộ trình thực tế hơn (26 tuần thay vì 20).

> zero-knowledge là **mục tiêu kiến trúc**, không phải bảo đảm tuyệt đối. Không cam kết "không bao giờ bị lộ". Với web, người dùng vẫn phải tin kênh phát hành mã tại thời điểm tải.

---

## 2. Mục tiêu và tiêu chí chấp nhận

| Mục tiêu | Tiêu chí chấp nhận (đo được) |
|---|---|
| Tiếng Việt toàn bộ | 100% màn hình, lỗi, thông báo, email, trợ giúp, quy trình khôi phục bằng tiếng Việt; kiểm bằng rà soát chuỗi |
| Mật khẩu tiếng Việt nhất quán | Cùng mật khẩu có dấu gõ trên hai bộ gõ/hệ điều hành mở được cùng một két (chuẩn hóa NFKC) |
| Đồng bộ đa thiết bị | Mục tạo trên Web xuất hiện và giải mã được trên Android/iOS sau đăng nhập; không mất hay trùng bản ghi trong 1.000 vòng ghi đồng thời thử nghiệm |
| Bảo vệ dữ liệu | Không plaintext, mật khẩu chính, SK, Recovery Key, rootKey nào xuất hiện trong request, log, DB (kiểm bằng dump và proxy) |
| Chịu lộ DB | Với bản sao DB đầy đủ nhưng không có SK, không dựng lại được KEK (bài kiểm thử đối kháng) |
| Chịu backend bị chiếm | Thiết bị giả do server chèn bị thiết bị tin cậy phát hiện; deploy artifact không ký bị chặn |
| Khôi phục | Các kịch bản A–F (TD §6) thực hiện thành công trong diễn tập; kịch bản D xác nhận dữ liệu cũ không thể giải mã |
| Sẵn sàng | Mục đã tải xem được ngoại tuyến sau khi mở khóa; đồng bộ lại tự động; mục tiêu uptime 99,9% sau ổn định (đề xuất) |
| Hiệu năng | Mở danh sách 1.000 mục < 2 giây trên thiết bị tham chiếu; p95 API đọc ciphertext < 400 ms (đo bằng benchmark) |
| An toàn phát hành | Không còn lỗ hổng Critical/High; pentest và review mật mã độc lập; qua SG0–SG3 |

---

## 3. Phạm vi

### 3.1 MVP (beta có kiểm soát)

- Đăng ký (OTP email), đăng nhập OPAQUE, MFA, quản lý phiên và thiết bị, phê duyệt thiết bị bằng QR.
- Tạo/mở khóa két; thêm/sửa/xóa/tìm kiếm cục bộ; bộ sinh mật khẩu.
- Danh mục: Website/App, Ngân hàng (chỉ thông tin nhận diện), Ví, Giấy tờ, Ghi chú.
- Đồng bộ bản mã, xử lý xung đột (giữ của tôi / giữ server / giữ cả hai), chế độ ngoại tuyến.
- Emergency Kit (Secret Key + Recovery Key), khôi phục A–F, xuất/nhập sao lưu mã hóa `.ksvbackup`.
- Tệp đính kèm ≤ 10 MiB (P1).
- Sinh trắc học mở khóa (mobile) qua Keychain/Keystore.
- Nhật ký bảo mật cho người dùng (S19), thông báo thiết bị mới/khôi phục.

### 3.2 Ngoài phạm vi MVP

Tự điền trên trình duyệt/ứng dụng, extension, đồng bộ passkey, chia sẻ két nhóm/gia đình, quản trị doanh nghiệp, OCR giấy tờ, thanh toán, lưu CVV/PIN/OTP giao dịch, khôi phục mà máy chủ đọc được dữ liệu, SMS OTP.

---

## 4. Người dùng, vai trò và kịch bản

| Vai trò | Quyền |
|---|---|
| Người dùng | Tạo và dùng két, quản lý thiết bị/phiên, xuất sao lưu, xem nhật ký bảo mật |
| Quản trị vận hành | Giám sát hệ thống và số liệu không nhạy cảm; **không** xem được nội dung két; truy cập đặc quyền theo yêu cầu, có thời hạn |
| Nhân viên hỗ trợ | Hướng dẫn quy trình; không thể giải mã két, không thể bỏ qua thời gian chờ khôi phục |

| Mã | Kịch bản |
|---|---|
| US-01 | Tạo tài khoản, đặt mật khẩu chính, nhận Emergency Kit và xác nhận đã lưu; hiểu rằng mất cả mật khẩu chính lẫn Recovery Key thì không khôi phục được dữ liệu |
| US-02 | Thêm thông tin đăng nhập, sao chép mật khẩu, clipboard tự xóa |
| US-03 | Mất điện thoại, đăng nhập máy mới, được thiết bị còn lại phê duyệt bằng QR |
| US-04 | Sửa cùng một mục trên hai thiết bị; thấy màn hình xung đột, không bị ghi đè âm thầm |
| US-05 | Không có mạng vẫn xem/sửa dữ liệu đã đồng bộ; có mạng thì tự đồng bộ |
| US-06 | Thu hồi thiết bị thất lạc; hiểu rằng bản sao đã tải trên thiết bị đó không thu hồi được |
| US-07 | Nhận cảnh báo "thiết bị mới được thêm" và hủy nếu không phải mình |
| US-08 | Quên mật khẩu chính, khôi phục bằng Recovery Key sau thời gian chờ có thông báo |
| US-09 | Nhận email giả mạo; ứng dụng và email của sản phẩm luôn nhắc không bao giờ hỏi mật khẩu/OTP ngoài ứng dụng |

---

## 5. Yêu cầu chức năng

| Mã | Yêu cầu | Ưu tiên | Tiêu chí nghiệm thu chính |
|---|---|---|---|
| FR-01 | Đăng ký/đăng nhập: OTP email, OPAQUE, giới hạn tần suất, phản hồi không lộ sự tồn tại tài khoản | P0 | Phản hồi tài khoản có/không không phân biệt được; 5 lần thất bại bị làm chậm |
| FR-02 | Khởi tạo két: Secret Key, rootKey, Recovery Key tùy chọn, phân cấp khóa theo TD §3 | P0 | Test vectors; dump DB không có khóa/mật khẩu rõ |
| FR-03 | CRUD mục, danh mục, tìm kiếm cục bộ, bộ sinh mật khẩu CSPRNG | P0 | Tìm kiếm không gửi request mạng |
| FR-04 | Đồng bộ theo `change_seq`, `If-Match`, 409 + hòa giải, tombstone, full resync, phát hiện rollback | P0 | Test đồng thời và xung đột (TD §13) |
| FR-05 | Cache ngoại tuyến mã hóa, hàng đợi ghi, idempotency | P0 | Không tạo bản trùng khi mạng chập chờn |
| FR-06 | Khóa tự động, sinh trắc học (mobile), xóa clipboard | P0 | Khóa sau 1 phút nền / 5 phút không thao tác |
| FR-07 | Sao lưu `.ksvbackup`, nhập lại, kiểm tra toàn vẹn | P0 | Nhập bản bị sửa 1 bit → từ chối |
| FR-08 | Phiên và thiết bị: danh sách, thu hồi, phát hiện tái dùng refresh token, chữ ký thiết bị | P0 | Reuse → thu hồi cả họ phiên |
| FR-09 | Phê duyệt thiết bị bằng QR; đường dự phòng chờ 24 giờ | P0 | Khóa công khai bị thay → từ chối |
| FR-10 | Khôi phục A–F, thông báo mọi nơi, hủy từ thiết bị tin cậy | P0 | Diễn tập từng kịch bản |
| FR-11 | MFA: WebAuthn, TOTP, mã dự phòng | P0 | Đăng ký/đăng nhập/mất MFA |
| FR-12 | Nhật ký bảo mật cho người dùng, thông báo sự kiện nhạy cảm | P0 | Mọi sự kiện trong `audit_events` hiển thị đúng |
| FR-13 | Tệp đính kèm mã hóa theo chunk, ≤ 10 MiB | P1 | Chunk bị sửa → từ chối toàn bộ |
| FR-14 | Xóa tài khoản (chờ 7 ngày, hủy được) và xuất dữ liệu | P1 | Xóa đến bản sao lưu theo chính sách lưu giữ |
| FR-15 | Trang trạng thái, banner thông báo sự cố trong ứng dụng | P1 | Hiển thị khi SEV1 được công bố |
| FR-16 | Tự điền, extension, passkey, chia sẻ nhóm | P2 | Giai đoạn sau, cần thiết kế riêng |

---

## 6. Yêu cầu phi chức năng

- **NFR-01** Bảo mật theo OWASP ASVS cấp 2 (web/API) và MASVS (mobile); threat model trước khi viết mã; review hai người cho `crypto` và `auth`.
- **NFR-02** TLS 1.3 ưu tiên (tối thiểu 1.2), HSTS, CSP + Trusted Types, SRI, CORS allowlist, không cache dữ liệu nhạy cảm.
- **NFR-03** Không ghi plaintext/bí mật vào log, analytics, crash report, clipboard history, thông báo; log theo allowlist.
- **NFR-04** Khả năng phục hồi dịch vụ: RPO ≤ 1 giờ, RTO ≤ 4 giờ (đề xuất; xác nhận bằng diễn tập quý).
- **NFR-05** Hiệu năng: xem mục 2.
- **NFR-06** Trình duyệt hiện đại; Android/iOS còn được hỗ trợ; WCAG 2.2 AA cơ bản; hỗ trợ phông chữ lớn.
- **NFR-07** Metadata tối thiểu: máy chủ thấy email, thời điểm đồng bộ, kích thước bản mã đã đệm, IP dạng HMAC; chính sách lưu giữ: audit 180 ngày, tombstone 90 ngày, revision 90 ngày.
- **NFR-08** Chuỗi cung ứng: toàn bộ yêu cầu ở `an-ninh/Kiem_soat_Chuoi_Cung_ung_va_CICD.md` được đáp ứng trước SG0.
- **NFR-09** Khả năng quan sát: giám sát toàn vẹn bundle web, cảnh báo bất thường truy cập dữ liệu, tài khoản canary.
- **NFR-10** Tương thích dữ liệu: mọi định dạng (envelope, backup, kdf_params) có `version`; nâng cấp có đường di trú đã kiểm thử.

---

## 7. Kiến trúc tóm tắt

Web (Next.js PWA) và Mobile (React Native) dùng chung Crypto SDK → HTTPS → API NestJS (module `auth`, `vault`) → PostgreSQL (RLS) và Object Storage (bản mã). Mã web phát hành từ static host riêng, có ký và giám sát. Chi tiết: Technical Design, `diagrams/architecture.mmd`.

---

## 8. Pháp lý, riêng tư và dữ liệu

Căn cứ đã tra cứu (cần tư vấn pháp lý xác nhận trước thương mại hóa):

- **Luật Bảo vệ dữ liệu cá nhân số 91/2025/QH15**, hiệu lực 01/01/2026.
- **Nghị định 356/2025/NĐ-CP** hướng dẫn thi hành, hiệu lực 01/01/2026, thay thế Nghị định 13/2023/NĐ-CP (các tài liệu nào còn viện dẫn Nghị định 13/2023 cần cập nhật).
- **Nghị định 330/2026/NĐ-CP** về xử phạt vi phạm hành chính trong an ninh mạng và bảo vệ dữ liệu cá nhân, hiệu lực 19/08/2026.
- Nghĩa vụ thông báo vi phạm trong **72 giờ** khi sự cố thuộc diện phải thông báo; đánh giá tác động xử lý dữ liệu (DPIA) và nhân sự/đầu mối bảo vệ dữ liệu theo quy định.

Việc cần làm: lập DPIA trước SG3; chỉ định đầu mối bảo vệ dữ liệu; chính sách riêng tư và điều khoản tiếng Việt; quy trình đáp ứng yêu cầu chủ thể dữ liệu (xóa, truy cập); đánh giá chuyển dữ liệu ra nước ngoài nếu dùng hạ tầng ngoài Việt Nam (ADR-08); không thu thập ảnh CCCD hay dữ liệu ngoài mục đích người dùng chủ động lưu; mốc xóa dữ liệu gắn với bản sao lưu.

---

## 9. Lộ trình và các cổng (ước tính, không phải cam kết)

| Giai đoạn | Thời lượng | Sản phẩm bàn giao | Cổng |
|---|---|---|---|
| 0. Nền tảng an toàn | 3 tuần | PRD/SRS chốt, ADR chốt, threat model, **GitHub/CI hardening**, UX prototype | **SG0** |
| 1. Spike mật mã và hạ tầng | 4 tuần | Crypto SDK, OPAQUE PoC, test vectors chéo nền tảng, khung API/DB + RLS, pipeline ký/provenance | **SG1** |
| 2. Web MVP | 5 tuần | Đăng ký/đăng nhập, két, đồng bộ, offline, backup, phê duyệt thiết bị, giám sát bundle | |
| 3. Mobile MVP | 6 tuần | Android/iOS, Keychain/Keystore, sinh trắc, QR phê duyệt, đồng bộ | **SG2** |
| 4. Hardening và QA | 5 tuần | E2E, pentest + review mật mã, diễn tập khôi phục và sự cố, DPIA | **SG3** |
| 5. Beta có kiểm soát | 3 tuần | Phát hành giới hạn, theo dõi, bug bounty nội bộ | **SG4** (GA) |

**Tổng ước tính ≈ 26 tuần** (so với ≈ 20 tuần ở v1). Giai đoạn 2 và 3 có thể chồng một phần nếu đủ nhân lực; thời gian thực tế phụ thuộc quy mô đội, kết quả spike và lịch của bên kiểm toán độc lập. Chưa ước lượng chi phí: chốt sau giai đoạn 0 khi có nhân sự, SLA và bên kiểm toán.

---

## 10. Đội ngũ gợi ý

1 PM/BA (bán thời gian), 1 UX/UI, 1 frontend web, 2 mobile, 1–2 backend, 1 QA tự động hóa, 1 DevOps/nền tảng (**toàn thời gian từ giai đoạn 0**), 1 chuyên gia mật mã/bảo mật (theo đợt, độc lập), 1 đầu mối pháp lý/DPO (bán thời gian). Bên kiểm toán/pentest độc lập đặt lịch từ giai đoạn 1 vì thường kín lịch.

---

## 11. Sổ đăng ký rủi ro dự án

| ID | Rủi ro | Xác suất | Tác động | Giảm thiểu | Chủ sở hữu |
|---|---|---|---|---|---|
| PR-01 | Thư viện OPAQUE không đạt trên RN/Hermes | TB | Cao | Spike S1 sớm; có phương án giao thức dự phòng đã thẩm định | Trưởng kỹ thuật |
| PR-02 | Argon2id quá nặng trên máy yếu/trình duyệt di động | TB | TB | Hiệu chỉnh tham số, sàn OWASP, đo trên thiết bị tham chiếu thấp nhất | Mobile/Web |
| PR-03 | Người dùng mất Emergency Kit | Cao | TB | UX bắt xác nhận; xuất kit lại từ thiết bị tin cậy; cảnh báo rõ | UX |
| PR-04 | Kiểm toán độc lập trễ lịch | TB | Cao | Đặt lịch sớm; cổng SG3 không nhượng bộ | PM |
| PR-05 | Đội bỏ qua kiểm soát CI/CD vì chậm tiến độ | TB | Rất cao | Đưa vào SG0, đo bằng chỉ số, DevOps toàn thời gian | PM/DevOps |
| PR-06 | Quy định pháp lý thay đổi/chưa rõ hướng dẫn | TB | TB | Tư vấn pháp lý sớm, thiết kế tối thiểu dữ liệu | Pháp lý |
| PR-07 | Phụ thuộc/thư viện bị đầu độc | TB | Cao | Ghim, chờ 14 ngày, SCA, SBOM | DevOps |
| PR-08 | Lệch phạm vi (thêm chia sẻ nhóm, autofill) | Cao | TB | Ngoài phạm vi MVP, chỉ sau SG4 | PM |

---

## 12. Tiêu chí Go/No-Go trước khi lưu dữ liệu thật

**GO** chỉ khi: SG0–SG3 đạt; giao thức mật mã/xác thực được chuyên gia độc lập duyệt; toàn bộ test P0 đạt; pentest không còn Critical/High; diễn tập khôi phục A–F và sự cố SEV1 hoàn tất; giám sát toàn vẹn bundle web và cảnh báo canary đang chạy; DPIA, chính sách riêng tư, điều khoản đầy đủ; runbook được dùng thử. Nếu không đạt: chỉ dùng dữ liệu giả trong môi trường thử nghiệm.

---

## 13. Quyết định

Đã chốt (ADR-01…ADR-12) — xem `ky-thuat/Quyet_dinh_kien_truc_ADR.md`. Còn mở sau spike: thư viện cụ thể cho OPAQUE/Argon2id trên RN; nhà cung cấp email và hạ tầng; xác nhận pháp lý về vị trí dữ liệu (ADR-08); mức SLA/ngân sách; mục tiêu số người dùng.

## Phụ lục — Quan hệ với bản MVP HTML trước đó

Bản demo HTML (PBKDF2, lưu trữ cục bộ) chỉ là prototype; không tái sử dụng thiết kế lưu trữ, xác thực hay mã mật mã của nó.
