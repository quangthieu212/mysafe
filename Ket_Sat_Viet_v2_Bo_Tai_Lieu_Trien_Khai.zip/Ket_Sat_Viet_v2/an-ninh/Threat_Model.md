# Threat Model — Két Sắt Việt v2.0

Cập nhật 26/11/2026 | Phạm vi: Web, Android, iOS, API, DB, object storage, kênh phát hành.

## 1. Tài sản

| Mã | Tài sản | Giá trị |
|---|---|---|
| T1 | Nội dung két (mật khẩu, giấy tờ, ghi chú, tệp) | Rất cao |
| T2 | Mật khẩu chính, Secret Key, Recovery Key, rootKey | Rất cao |
| T3 | Tính toàn vẹn mã client (JS web, app) | Rất cao |
| T4 | Khả năng truy cập tài khoản (phiên, thiết bị, khôi phục) | Cao |
| T5 | Metadata (email, thời điểm đồng bộ, kích thước bản mã, IP băm) | Trung bình–Cao |
| T6 | Khóa/bí mật hạ tầng (KMS, CI/CD, DB) | Cao |

## 2. Kẻ tấn công

| Mã | Kẻ tấn công | Năng lực giả định |
|---|---|---|
| A1 | Kẻ đọc được bản sao DB/object storage | Có toàn bộ bản mã và metadata |
| A2 | Kẻ chiếm backend hoặc CI/CD (kiểu sự cố 1Password) | Chạy mã tùy ý trên API, đổi mã phát hành |
| A3 | Kẻ chiếm email người dùng | Nhận mọi OTP/email |
| A4 | Kẻ có thiết bị người dùng (mất cắp) | Thiết bị khóa hoặc đang mở |
| A5 | Phishing/credential stuffing | Có email, có thể có mật khẩu rò rỉ |
| A6 | Nội gián / tài khoản lập trình viên bị chiếm | Quyền repo/CI theo vai trò |

## 3. Mối đe dọa, kiểm soát, rủi ro còn lại

Mức: K (khả năng), T (tác động), 1–5. Rủi ro còn lại sau kiểm soát: Thấp / TB / Cao.

| ID | Mối đe dọa | Kẻ | K | T | Kiểm soát (tham chiếu) | Kiểm thử | Còn lại |
|---|---|---|---|---|---|---|---|
| TM-01 | Chiếm tài khoản GitHub, đẩy mã độc qua CI/CD | A6, A2 | 4 | 5 | FIDO2, ruleset, CODEOWNERS, OIDC, cổng duyệt 2 người, deploy xác minh chữ ký (Chuỗi cung ứng A–C) | Thử bypass, thử deploy không ký | TB |
| TM-02 | Thay JS web để lấy mật khẩu chính | A2 | 3 | 5 | Static host riêng, SRI, CSP/Trusted Types, giám sát hash, bundle ký (TD §10) | Giả lập đổi bundle, cảnh báo ≤ 5 phút | **Cao** (giới hạn bản chất của web) |
| TM-03 | Dò mật khẩu chính offline sau khi lộ DB | A1, A2 | 4 | 5 | Secret Key vào KEK/authSecret; Argon2id; OPAQUE (TD §3, §4) | Xác nhận không thể dựng lại KEK nếu thiếu SK | Thấp |
| TM-04 | Lộ OTP/token email | A1, A2, A3 | 4 | 4 | OTP chỉ lưu HMAC, 10 phút, 5 lần thử, gắn clientNonce, không link; thao tác nhạy cảm cần MFA + chờ | Dump DB không dùng được OTP | TB |
| TM-05 | Chiếm email → khôi phục/đặt lại tài khoản | A3 | 3 | 4 | MFA, chờ 24/72 giờ, thông báo mọi nơi, thiết bị tin cậy hủy; bản mã cũ giữ 30 ngày (TD §6) | Thử khôi phục khi không có MFA | TB (có thể gây từ chối dịch vụ) |
| TM-06 | Server thêm thiết bị giả (thay khóa công khai) | A2 | 3 | 5 | QR + so khớp khóa + chữ ký; SK chỉ gửi niêm tới khóa đã xác minh (TD §5) | Giả mạo khóa → thiết bị tin cậy từ chối | Thấp |
| TM-07 | Đánh cắp refresh/access token | A5, A2 | 3 | 4 | Token ngắn hạn, xoay vòng + phát hiện tái dùng, chữ ký thiết bị, cookie `__Host-` | Dùng token từ máy khác → thất bại | Thấp |
| TM-08 | Credential stuffing/brute force | A5 | 5 | 3 | OPAQUE + giới hạn tần suất + MFA; phản hồi giả (TD §4) | Thử giới hạn, đo thời gian phản hồi | Thấp |
| TM-09 | Dò tài khoản (user enumeration) | A5 | 4 | 2 | Phản hồi giả xác định, 202 đồng nhất cho OTP | So sánh phản hồi tài khoản có/không | Thấp |
| TM-10 | IDOR/BOLA đọc két người khác | A5, A2 | 3 | 5 | RLS FORCE, `app.user_id`, 404 thay 403, test hai tài khoản | Thử mọi endpoint, thử bỏ `app.user_id` | Thấp |
| TM-11 | Rollback/tráo bản mã bởi server | A2 | 2 | 4 | Revision trong AAD, `changeSeq` cao nhất ở client, cảnh báo giảm | Test đưa bản cũ | TB (không chặn được rollback toàn bộ khi client mới) |
| TM-12 | Rò rỉ metadata (email, kích thước, thời điểm) | A1, A2 | 4 | 3 | Đệm payload, mã hóa tên/URL/nhãn, IP băm có khóa xoay, retention 180 ngày (TD §3.3, §9) | Rà soát schema, dump không có plaintext | TB |
| TM-13 | Thiết bị mất/bị chiếm khi đang mở khóa | A4 | 3 | 5 | Tự khóa, sinh trắc niêm trong Keystore, thu hồi từ xa, xoay khóa khi nghi ngờ (TD §8) | Kiểm thử khóa/thu hồi | TB (dữ liệu đã tải không thu hồi được) |
| TM-14 | Mã độc trên thiết bị người dùng | A4 | 3 | 5 | Cảnh báo root/jailbreak, hạn chế clipboard/screenshot; không có phòng thủ trọn vẹn | — | **Cao** (ngoài phạm vi kiểm soát) |
| TM-15 | Phụ thuộc bị đầu độc (npm, thư viện crypto) | A6, A2 | 3 | 5 | Ghim phiên bản, chờ 14 ngày, `--ignore-scripts`, SCA, SBOM, review cho crypto/auth | Thêm phụ thuộc giả có script cài đặt | TB |
| TM-16 | Lộ khóa KMS/bí mật CI | A2, A6 | 3 | 5 | OIDC, environment secret, xoay vòng theo lịch + sự cố, tách quyền | Diễn tập xoay vòng | TB |
| TM-17 | Rút dữ liệu hàng loạt từ backend bị chiếm | A2 | 3 | 4 | Egress allowlist, cảnh báo số hàng đọc, canary, RLS | Mô phỏng truy vấn hàng loạt | TB |
| TM-18 | Trùng nonce / lỗi AEAD | — | 1 | 5 | Nonce 24 byte ngẫu nhiên, test vectors, thư viện đã kiểm toán | Thử 10⁶ lần mã hóa | Thấp |
| TM-19 | Mất dữ liệu do quên mật khẩu/mất kit | Người dùng | 4 | 4 | Emergency Kit, xác nhận đã lưu, cảnh báo rõ, xuất `.ksvbackup` (TD §6, §12) | Diễn tập khôi phục A–F | TB (đánh đổi bản chất) |
| TM-20 | Phishing người dùng (email giả mạo) | A5 | 5 | 4 | Không link trong email, DMARC/SPF/DKIM, thông điệp "không bao giờ hỏi mật khẩu", MFA/WebAuthn | Kiểm thử mẫu email | TB |
| TM-21 | Gián đoạn dịch vụ / mất DB | — | 2 | 4 | Sao lưu + PITR, diễn tập quý, RPO ≤ 1 giờ, RTO ≤ 4 giờ | Diễn tập phục hồi | Thấp |
| TM-22 | Vi phạm tuân thủ (chậm thông báo, chuyển dữ liệu) | — | 3 | 4 | Runbook, DPO/đầu mối, DPIA, ADR-08 | Diễn tập mốc 72 giờ | TB |

## 4. Giả định và ngoài phạm vi

- Thư viện mật mã và OPAQUE được chọn đúng như thiết kế; phần ghép nối do chuyên gia độc lập duyệt.
- Không chống được kẻ kiểm soát đồng thời thiết bị đang mở khóa và hệ điều hành (TM-14).
- Không bảo vệ khỏi người dùng tự lộ mật khẩu chính + Emergency Kit.
- Tấn công vật lý vào nhà cung cấp cloud, tấn công DoS cấp mạng lớn: dựa vào nhà cung cấp và WAF/CDN.

## 5. Rà soát

Rà soát threat model: mỗi cổng SG, sau mỗi thay đổi giao thức/khóa, và sau mỗi sự cố nghiêm trọng (cập nhật `K` và kiểm soát).
