# Kiểm soát chuỗi cung ứng, GitHub và CI/CD — Két Sắt Việt v2.0

Cập nhật 26/11/2026 | Yêu cầu bắt buộc của cổng SG0 (ADR-12)

**Nguồn bối cảnh:** các bài báo ngày 25–26/11/2026 về sự cố 1Password (chưa đối chiếu bài công bố gốc của hãng). Theo các bài đó, kẻ tấn công chiếm tài khoản GitHub của một nhân viên, truy cập mã nguồn, vào môi trường CI/CD và đẩy mã độc lên dịch vụ backend để lấy dữ liệu khách hàng; kho mật khẩu được cho là không bị truy cập. Tài liệu này không giả định chi tiết nào ngoài những điều đó.

---

## 1. Phân tích chuỗi tấn công và điểm cắt

| Bước tấn công | Kiểm soát cắt chuỗi | Mục | Kiểm chứng |
|---|---|---|---|
| 1. Chiếm tài khoản GitHub của lập trình viên | Khóa FIDO2/passkey bắt buộc; SSO; thiết bị được quản lý; cảnh báo đăng nhập bất thường | A | Thử đăng nhập bằng mật khẩu + TOTP phải bị từ chối |
| 2. Đọc mã nguồn riêng | Quyền tối thiểu theo repo; không có thành viên "đọc mọi repo"; mã không chứa bí mật | A, B | Rà soát quyền hằng quý; secret scanning |
| 3. Đẩy mã độc vào repo/workflow | Nhánh bảo vệ, 2 reviewer, CODEOWNERS cho `.github/workflows`, `packages/crypto`, `services/api`, `infra` | B | Thử push thẳng và merge không duyệt phải thất bại |
| 4. Lấy bí mật CI/CD | OIDC thay khóa tĩnh; secret theo environment; runner tạm thời; không dùng `pull_request_target` với mã không tin cậy | C | Quét workflow; thử đọc secret production từ nhánh feature |
| 5. Triển khai mã độc lên backend/CDN | Chữ ký artifact + provenance; bước deploy xác minh chữ ký; cổng production 2 người + chờ | C | Thử deploy artifact không ký |
| 6. Rút dữ liệu từ backend | Egress allowlist; RLS; cảnh báo số hàng đọc; tài khoản canary; dữ liệu nhạy cảm chỉ ở dạng băm có khóa/bản mã | D | Mô phỏng truy vấn hàng loạt phải sinh cảnh báo |
| 7. Tác động lên người dùng | Bản mã + Secret Key; OTP/token chỉ lưu băm; thông báo nhanh | Thiết kế | Diễn tập sự cố |

---

## A. Danh tính và thiết bị lập trình viên

1. GitHub Organization bật **SAML SSO** với IdP của công ty; **bắt buộc khóa bảo mật FIDO2/passkey** (không chấp nhận SMS/TOTP cho tài khoản có quyền ghi).
2. Cấm PAT cổ điển; PAT fine-grained chỉ khi có phê duyệt, hạn ≤ 30 ngày; ưu tiên GitHub App. Khóa SSH dùng loại gắn khóa phần cứng (`sk-ssh-ed25519`).
3. Chỉ máy được quản lý (mã hóa đĩa, EDR, cập nhật tự động) được truy cập repo sản xuất; xem xét ràng buộc theo thiết bị ở IdP.
4. Tài khoản quản trị tách riêng khỏi tài khoản hằng ngày; không có quyền admin thường trực; số owner ≤ 3.
5. Offboarding thu hồi toàn bộ quyền trong ≤ 1 giờ; rà soát quyền hằng quý.
6. Phát hiện: đẩy log kiểm toán GitHub (đăng nhập, tạo token, thay đổi quyền, force-push, clone hàng loạt) vào hệ thống giám sát; cảnh báo đăng nhập từ vị trí/thiết bị mới.
7. Đào tạo phishing có kiểm tra thực tế; quy tắc: không ai (kể cả quản lý) xin mã MFA hay token qua chat/email.

## B. Kho mã và nhánh

1. Ruleset cho `main` và `release/*`: bắt buộc PR, **2 phê duyệt** với đường dẫn nhạy cảm (CODEOWNERS), hủy phê duyệt khi có commit mới, bắt buộc kiểm tra trạng thái, cấm force-push, **không cho admin bypass**, merge queue.
2. CODEOWNERS bắt buộc cho: `.github/workflows/**`, `packages/crypto/**`, `services/api/src/auth/**`, `infra/**`, `apps/web/public/**` (cấu hình CSP/SRI).
3. Commit ký (GPG/SSH/Sigstore gitsign); tag phát hành chỉ do một nhóm nhỏ tạo và phải ký.
4. Bật secret scanning với push protection; không commit `.env`.
5. Phụ thuộc: lockfile bắt buộc; Renovate/Dependabot với **thời gian chờ tối thiểu 14 ngày** cho phiên bản mới (tránh bản bị đầu độc mới phát hành); ghim phiên bản chính xác cho `packages/crypto`; bản thay đổi phụ thuộc crypto/auth cần review của người phụ trách mật mã.

## C. CI/CD

1. Mọi `uses:` của GitHub Action **ghim theo commit SHA**; quyền mặc định `permissions: contents: read`, nâng quyền theo job.
2. Không dùng `pull_request_target` để checkout mã từ fork/nhánh không tin cậy; không chạy workflow từ fork với secret.
3. Runner **tạm thời** (ephemeral), cô lập mạng; không dùng runner tự lưu trạng thái.
4. Cloud: **OIDC** từ CI sang cloud với vai trò ngắn hạn, giới hạn theo repo + nhánh + environment; không có khóa truy cập tĩnh dài hạn.
5. Environment `staging` và `production`: người duyệt bắt buộc (2 người, không gồm tác giả), thời gian chờ tối thiểu 30 phút cho production; secret gắn theo environment.
6. Tách **build** và **deploy**: build sinh artifact + SBOM (CycloneDX) + **chứng thực provenance** + chữ ký (Sigstore/cosign); deploy chỉ chạy nếu xác minh được chữ ký và digest.
7. Cài đặt phụ thuộc trong CI bằng `npm ci --ignore-scripts` (chạy script cần thiết một cách tường minh); quét SCA, SAST, secret, lint workflow (ví dụ `actionlint`), quét image.
8. Admission ở production chỉ nhận image đã ký; không SSH vào máy production; hạ tầng bất biến.
9. Cửa sổ triển khai và cảnh báo: deploy ngoài cửa sổ hoặc ngoài pipeline → SEV1.

## D. Chạy thật (runtime)

1. **Egress allowlist** cho API/worker; mã độc không gửi dữ liệu ra ngoài tự do được.
2. Role DB tối thiểu (xem `schema.sql`); không có tài khoản DB người dùng thường trực; truy cập đặc quyền theo yêu cầu, có thời hạn, ghi nhật ký.
3. Cảnh báo bất thường: số hàng đọc/giây, truy vấn quét bảng `vault_items`, tải xuống object storage hàng loạt.
4. **Tài khoản và mục canary**: vài tài khoản giả có dữ liệu giả; mọi lần đọc ngoài kịch bản kiểm thử là cảnh báo SEV1.
5. OTP, mã dự phòng, refresh token, token phiên khôi phục chỉ lưu băm (có khóa với OTP/mã dự phòng); không bao giờ ghi vào log.
6. Bí mật hạ tầng trong secret manager/KMS; xoay vòng theo lịch và theo sự cố (xem runbook P1).

## E. Toàn vẹn mã web

Xem Technical Design mục 10 và ADR-04: static host riêng; bundle build tái lập; manifest ký; giám sát độc lập mỗi 5 phút; CSP/Trusted Types/SRI; phát hành cần 2 người + khóa ký ngoài băng.

## F. Chỉ số theo dõi

| Chỉ số | Mục tiêu |
|---|---|
| Thời gian từ phát hiện đến cô lập (MTTC) | ≤ 1 giờ cho SEV1 |
| Thời gian từ phát hiện đến thông báo nội bộ | ≤ 15 phút |
| Tỷ lệ tài khoản có quyền ghi dùng FIDO2 | 100% |
| Số PAT dài hạn đang hoạt động | 0 |
| Action chưa ghim SHA | 0 |
| Tỷ lệ phát hành có 2 người duyệt + chữ ký hợp lệ | 100% |

## G. Danh sách kiểm tra trước SG0

- [ ] SSO + FIDO2 bật cho 100% thành viên organization
- [ ] Ruleset nhánh + CODEOWNERS đã áp dụng và thử bypass thất bại
- [ ] Workflow ghim SHA, quyền tối thiểu, OIDC; không còn khóa cloud tĩnh
- [ ] Environment production có 2 người duyệt + chờ
- [ ] Build sinh SBOM, provenance, chữ ký; deploy xác minh được
- [ ] Log GitHub và cloud đổ vào giám sát, có cảnh báo
- [ ] Egress allowlist và canary hoạt động ở staging
- [ ] Đã diễn tập playbook P1 (chiếm tài khoản lập trình viên) trên giấy
