# Danh sách và đặc tả màn hình (v2.0)

| Mã | Màn hình | Thành phần | Yêu cầu bảo mật |
| --- | --- | --- | --- |
| S01 | Chào mừng | Tạo két sắt; Đăng nhập; Tìm hiểu bảo mật | Không gửi telemetry tự động; cảnh báo dữ liệu thử nghiệm đến khi qua SG3; liên kết tới trang bảo mật nêu giới hạn của bản web |
| S02 | Đăng ký | Email; nút gửi mã | Phản hồi giống nhau dù email đã tồn tại; không có liên kết trong email |
| S03 | Xác minh email | Ô nhập mã 8 chữ số; gửi lại sau 60 giây | Tối đa 5 lần thử; mã hết hạn 10 phút; nhắc 'chúng tôi không bao giờ hỏi mã qua điện thoại hay email' |
| S04 | Tạo mật khẩu chính | Mật khẩu; xác nhận; độ mạnh; cảnh báo không thể khôi phục | Chuẩn hóa NFKC; không gửi mật khẩu lên server; chặn mật khẩu phổ biến; kiểm tra gõ lại |
| S05 | Bộ khôi phục (Emergency Kit) | Secret Key; Recovery Key; in/lưu PDF; tùy chọn bỏ Recovery Key | Hiển thị một lần; không chụp màn hình; nêu rõ rủi ro khi kit bị lộ; không gửi qua email |
| S06 | Xác nhận đã lưu kit | Nhập lại 3 nhóm ký tự ngẫu nhiên | Bắt buộc trước khi vào két; app chọn nhóm ngẫu nhiên mỗi lần |
| S07 | Đăng nhập | Email; mật khẩu chính; (thiết bị mới) Secret Key hoặc quét QR | OPAQUE; chống brute-force; thông báo lỗi không phân biệt nguyên nhân |
| S08 | Xác thực hai yếu tố | WebAuthn; TOTP; mã dự phòng | 5 lần thử; không lưu mã dự phòng dạng rõ ở client sau khi hiển thị |
| S09 | Chờ phê duyệt (thiết bị mới) | Mã QR; vân tay 16 ký tự dự phòng; đồng hồ chờ nếu đường dự phòng | QR chứa khóa công khai + nonce; không có bản mã nào được tải trước khi duyệt |
| S10 | Phê duyệt thiết bị | Quét QR; thông tin thiết bị; Chấp nhận / Từ chối | So khớp khóa với server; lệch → cảnh báo sự cố; yêu cầu xác thực lại |
| S11 | Trang chủ | Tìm kiếm; danh mục; mục gần đây; trạng thái đồng bộ; banner sự cố | Danh sách giải mã cục bộ; ẩn nội dung nhạy cảm trong thông báo |
| S12 | Danh sách mục | Lọc danh mục; sắp xếp; thêm mục | Tìm kiếm cục bộ; không gửi từ khóa lên server |
| S13 | Chi tiết mục | Tên; trường tùy chỉnh; sao chép; sửa; xóa | Ẩn mật khẩu mặc định; xóa clipboard sau 30 giây; xác nhận xóa |
| S14 | Thêm/sửa mục | Loại mục; nhãn; tên đăng nhập; mật khẩu; URL; ghi chú | Mã hóa trước khi gửi; cảnh báo mất thay đổi; không đưa dữ liệu vào URL |
| S15 | Bộ sinh mật khẩu | Độ dài; loại ký tự; kết quả | CSPRNG; không log; không tự gửi |
| S16 | Giấy tờ và tệp đính kèm | Loại giấy tờ; thông tin; tệp ≤ 10 MiB | Mã hóa tệp ở client theo chunk; xem chỉ sau khi kiểm toàn vẹn; tên tệp nằm trong bản mã |
| S17 | Xung đột đồng bộ | So sánh bản của tôi và bản server; Giữ của tôi / Giữ server / Giữ cả hai | Không tự gộp trường nhạy cảm; giữ bản sao an toàn đến khi giải quyết xong |
| S18 | Thiết bị và phiên | Danh sách; thu hồi; thiết bị hiện tại | Thu hồi chặn đồng bộ ngay; nêu rõ dữ liệu đã tải không thu hồi được; gợi ý xoay khóa khi nghi bị chiếm |
| S19 | Sự kiện bảo mật | Đăng nhập; thiết bị mới; khôi phục; đổi mật khẩu; cảnh báo | Hiển thị vùng/quốc gia thay vì IP; nút 'Không phải tôi' dẫn tới thu hồi và đổi mật khẩu |
| S20 | Sao lưu và khôi phục dữ liệu | Xuất .ksvbackup; nhập; kiểm tra toàn vẹn | Không xuất plaintext mặc định; khóa sao lưu riêng hoặc Recovery Key; không dùng lại mật khẩu chính |
| S21 | Khôi phục truy cập | Chọn tình huống A–F; đồng hồ chờ; nhập Recovery Key; đặt mật khẩu mới | Thông báo mọi thiết bị/email; có nút Hủy; sau khi xong thu hồi thiết bị khác |
| S22 | Bảo mật | Tự khóa; sinh trắc học; MFA; đổi mật khẩu; xoay Recovery Key; xem Secret Key | Xác thực lại ≤ 5 phút; sinh trắc niêm trong Keystore/Keychain; xem SK cần xác thực lại |
| S23 | Cài đặt và xóa tài khoản | Ngôn ngữ; chủ đề; tài khoản; xóa tài khoản | Xóa chờ 7 ngày, hủy được; nêu rõ phạm vi xóa bản sao lưu |
| S24 | Trợ giúp và thông báo sự cố | Hướng dẫn; liên hệ; trạng thái dịch vụ; thông báo sự cố bảo mật | Không hỏi bí mật ở bất kỳ kênh nào; liên kết chỉ tới tên miền chính thức |
