# Quyết định kiến trúc (ADR) — Két Sắt Việt v2.0

Cập nhật 26/11/2026. Các quyết định dưới đây đóng lại danh sách "cần chốt trước khi lập trình" của v1. Trạng thái **Đề xuất chốt** nghĩa là đã đủ để bắt đầu triển khai; mục "Xem lại khi" nêu điều kiện mở lại.

| ID | Quyết định | Trạng thái |
|---|---|---|
| ADR-01 | Xác thực bằng OPAQUE (RFC 9807) | Đề xuất chốt, chờ spike S1 |
| ADR-02 | Secret Key 128 bit trộn vào KEK và authSecret | Đề xuất chốt |
| ADR-03 | XChaCha20-Poly1305 + libsodium; HKDF-SHA256 | Đề xuất chốt, chờ spike S1 |
| ADR-04 | Phát hành web từ static host riêng, có ký và giám sát toàn vẹn | Đề xuất chốt |
| ADR-05 | Phê duyệt thiết bị bằng QR + chữ ký; đường dự phòng chờ 24 giờ | Đề xuất chốt |
| ADR-06 | OTP trong ứng dụng thay cho liên kết email | Đề xuất chốt |
| ADR-07 | Phiên: access 10 phút, refresh xoay vòng, gắn khóa thiết bị | Đề xuất chốt |
| ADR-08 | Dữ liệu đặt tại Việt Nam | Cần xác nhận pháp lý |
| ADR-09 | Khóa phụ MFA: WebAuthn khuyến nghị, TOTP hỗ trợ | Chốt |
| ADR-10 | Phạm vi MVP: cá nhân, có tệp đính kèm ≤ 10 MiB, không chia sẻ nhóm | Chốt |
| ADR-11 | Backend NestJS; hai module tách quyền DB | Chốt |
| ADR-12 | Bảo vệ chuỗi cung ứng là yêu cầu bắt buộc, không phải khuyến nghị | Chốt |

---

## ADR-01 — OPAQUE cho xác thực

**Bối cảnh.** v1 để trường `proof` là placeholder và gợi ý dùng verifier. Nếu verifier dẫn xuất xác định từ mật khẩu thì kẻ chiếm DB dò mật khẩu offline được; nếu dùng trực tiếp KEK làm verifier thì có thể bị phát lại.
**Quyết định.** Dùng OPAQUE (aPAKE, RFC 9807) với đầu vào là `authSecret` (ADR-02). Máy chủ không thấy mật khẩu kể cả lúc đăng ký; có cơ chế bản ghi giả để chống dò tài khoản.
**Lý do.** Tránh tự thiết kế giao thức xác thực; mật khẩu không bao giờ rời client; chống tính toán trước khi máy chủ bị chiếm.
**Hệ quả.** Phụ thuộc vào chất lượng thư viện (ứng viên là các binding của `opaque-ke`, cần spike cho Node và React Native). RFC 9807 mang trạng thái Informational (không phải tiêu chuẩn Internet) → cần cryptographer độc lập duyệt phần ghép nối.
**Xem lại khi.** Spike S1 không tìm được thư viện đạt test vectors RFC trên cả ba nền tảng. Phương án dự phòng: một giao thức khác cũng đã được thẩm định độc lập, không tự chế.

## ADR-02 — Secret Key (khóa bí mật thứ hai)

**Bối cảnh.** v1 chỉ dùng mật khẩu chính để dẫn xuất KEK, trong khi `users` lưu `wrapped_root_key` và verifier trên server. Một bản sao DB biến an toàn của toàn bộ két thành bài toán dò mật khẩu, mà mật khẩu người dùng thường yếu.
**Quyết định.** Sinh Secret Key 128 bit ở client; `KEK` và `authSecret` đều dẫn xuất từ `Argon2id(master) ‖ SK` qua HKDF với `info` khác nhau.
**Lý do.** Kẻ chỉ có DB phải vét cạn thêm 2¹²⁸ khả năng. Phù hợp mục tiêu chịu được sự cố kiểu "backend bị chiếm".
**Đánh đổi.** Thiết bị mới cần SK (QR từ thiết bị tin cậy hoặc nhập từ Emergency Kit); người dùng có thêm một thứ để giữ. Giảm nhẹ bằng QR và lưu SK trong Keychain/Keystore/IndexedDB đã bọc.
**Xem lại khi.** Thử nghiệm người dùng cho thấy tỷ lệ mất SK cao bất thường (khi đó xem xét chế độ "chỉ mật khẩu chính" kèm cảnh báo rủi ro, không phải mặc định).

## ADR-03 — Bộ mật mã

**Quyết định.** libsodium (bản đầy đủ): Argon2id, XChaCha20-Poly1305, secretstream, X25519/sealed box. HKDF-SHA256 lấy từ thư viện đã được kiểm toán (ví dụ `@noble/hashes`) hoặc triển khai native tương đương, kiểm bằng test vectors.
**Lý do.** Nonce 24 byte ngẫu nhiên loại bỏ rủi ro trùng nonce; một bộ thư viện cho web, Android, iOS; React Native không có WebCrypto đầy đủ.
**Hệ quả.** Không có khóa không-trích-xuất kiểu WebCrypto cho khóa dữ liệu trên web (chấp nhận, khóa nằm trong bộ nhớ JS). Khóa ký thiết bị P-256 vẫn dùng WebCrypto/Keystore/Secure Enclave vì các nơi này chỉ hỗ trợ P-256.
**Xem lại khi.** Spike S1 phát hiện vấn đề hiệu năng/độ tin cậy của binding trên Hermes; khi đó cân nhắc AES-256-GCM với khóa theo mục và tuân thủ giới hạn số lần dùng.

## ADR-04 — Phát hành web

**Bối cảnh.** Sự cố 1Password cho thấy kẻ có quyền đẩy mã vào CI/CD có thể đặt mã độc vào backend; với web, cùng đường đó có thể đặt mã độc vào JS giải mã.
**Quyết định.** Static host riêng ở tài khoản cloud riêng; bundle build tái lập, manifest hash ký ngoài băng và công khai; trình giám sát độc lập so hash mỗi 5 phút; CSP + Trusted Types + SRI; service worker ghim phiên bản.
**Hệ quả.** Thêm một thành phần hạ tầng và quy trình phát hành 2 người. Không loại bỏ hoàn toàn rủi ro (người dùng tin kênh phát hành khi tải mã) → khuyến nghị ứng dụng cài đặt cho nhóm rủi ro cao.

## ADR-05 — Phê duyệt thiết bị

**Quyết định.** Thiết bị mới hiển thị QR (khóa công khai + nonce); thiết bị tin cậy quét, đối chiếu với khóa server trả, ký phê duyệt và gửi SK đã niêm tới khóa X25519 của thiết bị mới. Không có thiết bị tin cậy: OTP + MFA + chờ 24 giờ, có thông báo và quyền hủy.
**Lý do.** Mã so khớp ngắn (6 chữ số) bị vét cạn được bởi máy chủ độc hại; QR mang đủ 256 bit. Khóa công khai thiết bị do server lưu có thể bị thay thế nếu server bị chiếm.

## ADR-06 — OTP trong ứng dụng

**Quyết định.** Xác minh email, đăng nhập thiết bị mới, khôi phục dùng mã 8 chữ số nhập trong ứng dụng, hiệu lực 10 phút, tối đa 5 lần thử, gắn `clientNonce`; chỉ lưu `HMAC(pepper_KMS, code ‖ id)`. Email không chứa liên kết bấm được.
**Lý do.** Trong sự cố 1Password, token nằm trong liên kết email bị lấy; liên kết cũng là mồi phishing. Mã nhập trong app, hết hạn nhanh, gắn nonce client và chỉ lưu băm có khóa làm giảm giá trị của dữ liệu bị lộ.
**Hệ quả.** OTP vẫn có thể bị phishing thời gian thực; vì vậy thao tác nhạy cảm còn đòi MFA, thời gian chờ và thông báo.

## ADR-07 — Phiên

Access token 10 phút; refresh xoay vòng, phát hiện tái sử dụng; yêu cầu chữ ký khóa thiết bị khi refresh và thao tác nhạy cảm; xác thực lại ≤ 5 phút cho thao tác phá hủy. Chi tiết: Technical Design mục 4.3.

## ADR-08 — Vị trí dữ liệu

**Đề xuất.** Đặt DB, object storage, sao lưu tại Việt Nam (hoặc khu vực được tư vấn pháp lý xác nhận), vì email, metadata, thời điểm đồng bộ vẫn là dữ liệu cá nhân dù nội dung két là bản mã. Nếu dùng hạ tầng ngoài Việt Nam, cần đánh giá việc chuyển dữ liệu ra nước ngoài theo quy định hiện hành.
**Trạng thái.** Cần xác nhận với tư vấn pháp lý (xem mục pháp lý trong PRD). Không ảnh hưởng thiết kế mật mã.

## ADR-09 — MFA

WebAuthn/passkey khuyến nghị; TOTP hỗ trợ; mã dự phòng. Không dùng SMS OTP (rủi ro SIM-swap, không cần thiết cho MVP).

## ADR-10 — Phạm vi MVP

Cá nhân; mục: đăng nhập web/app, ngân hàng (chỉ thông tin nhận diện), ví, giấy tờ, ghi chú; **tệp đính kèm ≤ 10 MiB** (P1); không CVV/PIN/OTP; không chia sẻ nhóm; không tự điền; không passkey sync. Chia sẻ nhóm cần thiết kế trao đổi khóa riêng, để sau SG4.

## ADR-11 — Backend

NestJS + TypeScript. Module `auth` dùng role DB `ksv_auth`, module `vault` dùng `ksv_app` (RLS theo `app.user_id`); worker dùng `ksv_worker` chỉ xóa dữ liệu hết hạn. Lý do: hạn chế phạm vi thiệt hại nếu một module bị khai thác.

## ADR-12 — Chuỗi cung ứng là yêu cầu bắt buộc

Các kiểm soát trong `an-ninh/Kiem_soat_Chuoi_Cung_ung_va_CICD.md` là điều kiện của cổng SG0, không phải việc làm sau. Lý do: đường tấn công thực tế (chiếm tài khoản lập trình viên → CI/CD → backend) bỏ qua toàn bộ mật mã của sản phẩm.
