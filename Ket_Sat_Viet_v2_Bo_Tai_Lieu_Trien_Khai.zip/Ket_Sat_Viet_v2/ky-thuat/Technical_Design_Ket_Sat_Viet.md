# Thiết kế kỹ thuật (Technical Design) — Két Sắt Việt

Phiên bản 2.0 | Cập nhật 26/11/2026 | Trạng thái: **bản thiết kế để triển khai, CHƯA kiểm toán bảo mật**

Thay thế bản 1.0 (28/10/2026). Danh sách thay đổi và lý do nằm trong `00-danh-gia/Danh_gia_ra_soat_v2.md`; các quyết định kiến trúc nằm trong `Quyet_dinh_kien_truc_ADR.md`. Tài liệu này dùng mã `F-xx` (phát hiện) và `ADR-xx` (quyết định) để truy vết.

> **Quy ước đọc:** mọi lựa chọn mật mã dưới đây là *thiết kế đề xuất để đưa vào spike và review độc lập*, không phải bảo đảm an toàn. Không triển khai cho dữ liệu thật trước khi qua cổng SG3 (mục 14).

---

## 1. Công nghệ

| Hạng mục | Lựa chọn | Ghi chú |
|---|---|---|
| Web | Next.js + TypeScript, PWA; mã giải mã chạy hoàn toàn ở client, **không dùng SSR cho dữ liệu két** | Phát hành từ static host riêng (ADR-04) |
| Mobile | React Native + TypeScript, module native cho Keychain/Keystore và crypto | |
| API | NestJS + TypeScript, OpenAPI 3.0.3 | Hai module tách quyền DB: `auth` (role `ksv_auth`) và `vault` (role `ksv_app`) |
| Cơ sở dữ liệu | PostgreSQL 16, Row-Level Security bắt buộc | `database/schema.sql` |
| Object storage | S3-compatible, chỉ bản mã, URL ký ngắn hạn | |
| Mật mã | libsodium (bản đầy đủ) cho Argon2id, XChaCha20-Poly1305, secretstream, X25519; HKDF-SHA256 từ thư viện đã được kiểm toán | ADR-03; xác nhận ở spike |
| Xác thực | OPAQUE (RFC 9807) + MFA (TOTP / WebAuthn) | ADR-01. RFC 9807 là tài liệu Informational của CFRG, không phải Internet Standard → cần review độc lập thư viện được chọn |
| Hàng đợi | Redis + worker (email, dọn dữ liệu), worker không đọc bản mã | |
| Khóa phía server | KMS: pepper HMAC (OTP, mã dự phòng, IP), khóa mã hóa phong bì cho bí mật TOTP | Không liên quan tới khóa két |

Không tự viết thuật toán mật mã. Chỉ viết "keo" (định dạng, thứ tự gọi) và kiểm thử bằng test vectors (mục 13).

---

## 2. Ranh giới tin cậy

- **Client (web/mobile)** là nơi duy nhất thấy khóa và plaintext.
- **API + DB + object storage** được giả định *có thể bị đọc trộm và có thể bị chiếm* (kịch bản 1Password: mã độc đẩy lên backend). Thiết kế phải bảo đảm kẻ chiếm backend **không** lấy được nội dung két, và bị hạn chế khi muốn chiếm tài khoản.
- **Kênh phát hành mã web** (GitHub → CI → CDN) là phần của ranh giới tin cậy với client web. Bị chiếm kênh này nghĩa là kẻ tấn công có thể sửa mã giải mã (F-01, F-02). Kiểm soát nằm trong `an-ninh/Kiem_soat_Chuoi_Cung_ung_va_CICD.md`.

Sơ đồ: `diagrams/architecture.mmd`.

---

## 3. Phân cấp khóa (F-03, F-10, F-14)

Sơ đồ: `diagrams/key-hierarchy.mmd`.

| Khóa | Nguồn | Lưu ở đâu | Dùng để |
|---|---|---|---|
| Mật khẩu chính | Người dùng nhớ | Không lưu | Đầu vào Argon2id |
| **Secret Key (SK)** 128 bit | CSPRNG trên client khi đăng ký | Emergency Kit (giấy/PDF), Keychain/Keystore (mobile), IndexedDB đã bọc (web, mục 3.2) | Trộn vào KEK và authSecret để lộ DB không đủ để dò mật khẩu offline |
| KEK | `HKDF(Argon2id(master) ‖ SK, info="ksv/v1/kek")` | Không lưu | Bọc rootKey |
| authSecret | `HKDF(Argon2id(master) ‖ SK, info="ksv/v1/opaque-password")` | Không lưu | "Mật khẩu" đưa vào OPAQUE |
| **rootKey (ARK)** 256 bit | CSPRNG | `users.wrapped_root_key` (bọc bởi KEK); `recovery_kits` (bọc bởi Recovery Key) | Gốc của mọi khóa két |
| Recovery Key 256 bit (tùy chọn) | CSPRNG | Emergency Kit | Bọc bản thứ hai của rootKey |
| vaultKey | CSPRNG theo két | `vaults.wrapped_vault_key` (bọc bởi khóa dẫn xuất từ ARK, info `ksv/v1/wrap-vault`) | Bọc itemKey |
| itemKey | CSPRNG theo mục | `vault_items.wrapped_item_key` (bọc bởi khóa dẫn xuất từ vaultKey, info `ksv/v1/wrap-item`) | Mã hóa payload mục |
| fileKey | CSPRNG theo tệp | `attachments.wrapped_file_key` | secretstream cho tệp đính kèm |

**Lợi ích so với v1:** đổi mật khẩu chỉ rewrap rootKey; xoay rootKey chỉ rewrap các vaultKey; xoay vaultKey chỉ rewrap itemKey (không phải mã hóa lại nội dung). Chỉ khi nghi ngờ lộ itemKey mới mã hóa lại một mục.

### 3.1 Chuẩn hóa và tham số KDF

- **Chuẩn hóa mật khẩu chính bằng Unicode NFKC, mã hóa UTF-8, trước Argon2id.** Tiếng Việt có dạng dựng sẵn và dạng tổ hợp (ví dụ "ế" có thể là 1 hoặc 2 điểm mã tùy bộ gõ/hệ điều hành); thiếu bước này, người dùng gõ cùng mật khẩu trên hai thiết bị có thể không mở được két. Test bắt buộc: cùng mật khẩu tiếng Việt ở dạng NFC và NFD phải cho cùng KEK.
- Argon2id: salt 16 byte theo tài khoản; **sàn** m ≥ 19 MiB, t ≥ 2, p = 1 (mức tối thiểu OWASP); **mục tiêu** hiệu chỉnh để 0,5–1 giây trên thiết bị tham chiếu thấp nhất được hỗ trợ, ưu tiên m ≥ 64 MiB. Tham số lưu trong `users.kdf_params` kèm `version`; tăng tham số khi đổi mật khẩu.
- Web dùng bản WASM của libsodium; giới hạn bộ nhớ trình duyệt di động có thể buộc hạ m — ghi nhận và bù bằng giá trị t cao hơn, không xuống dưới sàn.
- Secret Key hiển thị dạng Crockford Base32, 26 ký tự chia nhóm + 4 ký tự checksum; client kiểm checksum trước khi dẫn xuất.

### 3.2 Nơi giữ Secret Key theo nền tảng

| Nền tảng | Cách giữ | Hệ quả |
|---|---|---|
| Android/iOS | Keystore/Keychain, yêu cầu mở khóa thiết bị | Đăng nhập lần sau chỉ cần mật khẩu chính |
| Web | IndexedDB, đã bọc bằng khóa `HKDF(Argon2id(master), "ksv/v1/local-sk")` | Kẻ lấy được IndexedDB vẫn cần mật khẩu chính; trình duyệt mới phải nhập SK hoặc nhận qua QR từ thiết bị tin cậy |
| Thiết bị mới | Nhận qua QR/phê duyệt (mục 5) hoặc nhập từ Emergency Kit | |

### 3.3 Định dạng bản mã

AEAD: **XChaCha20-Poly1305**, nonce 24 byte ngẫu nhiên cho mỗi lần mã hóa, tag 16 byte (ADR-03: nonce 192 bit loại bỏ mối lo trùng nonce của AES-GCM 96 bit, và dùng chung một thư viện cho web/mobile).

AAD (nối theo thứ tự, mỗi trường có tiền tố độ dài):

| Đối tượng | AAD |
|---|---|
| wrappedRootKey | `"ksv/v1/wrap-root"`, userId, keyVersion |
| wrappedVaultKey | `"ksv/v1/wrap-vault"`, userId, vaultId, keyVersion |
| wrappedItemKey | `"ksv/v1/wrap-item"`, userId, vaultId, itemId, keyVersion |
| Payload mục | `"ksv/v1/item"`, userId, vaultId, itemId, schemaVersion, aadVersion, **revision**, keyVersion |
| Metadata tệp | `"ksv/v1/file-meta"`, userId, vaultId, itemId, attachmentId |

Revision trong AAD là `expectedRevision + 1` (trigger DB gán đúng giá trị này), nên server không thể gắn nhãn lại bản cũ thành bản mới mà client không phát hiện. Payload là JSON có phiên bản, **đệm** lên các bậc 256 B, 1 KiB, 4 KiB, 16 KiB, 64 KiB, 256 KiB để giảm rò rỉ độ dài.

Tệp đính kèm: `crypto_secretstream_xchacha20poly1305`, chunk 1 MiB, tag FINAL ở chunk cuối; client chỉ hiển thị sau khi kiểm xong toàn bộ luồng.

---

## 4. Đăng ký và đăng nhập (F-04, F-05, F-17)

Sơ đồ: `diagrams/encryption-flow.mmd`. Hợp đồng: `api/openapi.yaml`.

### 4.1 Đăng ký

1. Email → OTP 8 chữ số gửi qua email, **nhập trong ứng dụng** (không có liên kết bấm được) → `emailProof`.
2. Client sinh SK, rootKey, Recovery Key (nếu người dùng chọn), tính KEK và authSecret.
3. OPAQUE đăng ký bằng authSecret → `registrationRecord`.
4. Gửi `register/finish`: record, kdfParams, `wrappedRootKey`, `recoveryWrappedRootKey`, két đầu tiên, thiết bị (khóa công khai P-256 và X25519).
5. **Emergency Kit:** hiển thị SK + Recovery Key + email; bắt buộc người dùng xác nhận đã lưu bằng cách nhập lại 3 nhóm ký tự do app chọn ngẫu nhiên.

Máy chủ không bao giờ nhận mật khẩu chính, SK, Recovery Key, rootKey rõ.

### 4.2 Đăng nhập

1. `login/start` với KE1 của OPAQUE. Email không tồn tại vẫn trả phản hồi giả xác định (không lộ sự tồn tại tài khoản).
2. `login/finish` với KE3 → máy chủ trả một trong: `authenticated`, `mfa_required`, `device_approval_required`.
3. `mfa/verify` (TOTP / WebAuthn / mã dự phòng).
4. Thiết bị chưa biết → phê duyệt thiết bị (mục 5). Thiết bị đã biết → cấp token.
5. `GET /account/keys` trả `wrappedRootKey` + kdfParams; client giải mã cục bộ.

Vì authSecret chứa SK 128 bit, kẻ có bản sao DB (record OPAQUE, kdf_params, wrapped_root_key) **không thể dò mật khẩu chính offline** nếu không có SK. Việc chọn KSF của OPAQUE (đầu vào đã được kéo dãn và đã chứa SK) để spike S1 quyết định và cryptographer duyệt.

### 4.3 Phiên và token (F-16)

| Thành phần | Quy tắc |
|---|---|
| Access token | 10 phút, JWT ký EdDSA/ES256, chứa `sid`, `did`, `auth_time`, `amr`, `scope` |
| Refresh token | Web: cookie `__Host-ksv_rt` HttpOnly, Secure, SameSite=Strict. Mobile: Keychain/Keystore. Hết hạn trượt 30 ngày, tuyệt đối 90 ngày |
| Xoay vòng | Mỗi lần refresh đổi token; **dùng lại token cũ → thu hồi cả họ phiên** và cảnh báo người dùng |
| Gắn thiết bị | `/auth/refresh` và thao tác nhạy cảm yêu cầu header `X-Device-Signature` (ECDSA P-256 trên method ‖ path ‖ timestamp ‖ SHA-256(body)); token bị đánh cắp một mình không dùng được |
| Xác thực lại | Đổi mật khẩu, đổi MFA, xoay Recovery Key, xóa tài khoản yêu cầu `auth_time` ≤ 5 phút |
| Phạm vi hẹp | `pendingToken` (device_approval, recovery) chỉ gọi các endpoint tương ứng |

### 4.4 MFA

TOTP và WebAuthn/passkey; mã dự phòng 10 mã, mỗi mã một lần. Bí mật TOTP mã hóa phong bì bằng KMS (`secret_ciphertext`). WebAuthn được khuyến nghị; hiển thị cảnh báo khi người dùng chỉ có một yếu tố. Mất MFA: mã dự phòng, hoặc `mfa_reset` với OTP email + chờ 72 giờ + thông báo mọi thiết bị.

### 4.5 Giới hạn tần suất

| Điểm vào | Giới hạn mặc định |
|---|---|
| Gửi OTP | 3 mã/giờ/email; 10 mã/giờ/IP |
| Xác minh OTP | 5 lần/mã |
| `login/start`, `login/finish` | 5 lần thất bại/15 phút/tài khoản, tăng dần thời gian chờ; giới hạn theo IP và toàn cục |
| MFA | 5 lần/thử thách |
| Đồng bộ | 120 yêu cầu/phút/thiết bị |

Phản hồi 429 có `Retry-After`. Không phân biệt lý do thất bại trong thông báo lỗi đăng nhập.

---

## 5. Phê duyệt thiết bị mới (F-06)

Sơ đồ: `diagrams/device-approval.mmd`.

Mục tiêu: máy chủ (kể cả khi bị chiếm) **không thể âm thầm thêm thiết bị của kẻ tấn công**, và thiết bị mới nhận SK mà không cần gõ 26 ký tự.

**Đường chính (có thiết bị tin cậy):**
1. Thiết bị mới sinh khóa P-256 (ký) và X25519 (hộp), nonce 32 byte; gọi `POST /devices/approvals`; hiển thị **mã QR** chứa hai khóa công khai và nonce.
2. Thiết bị tin cậy quét QR, gọi `GET /devices/approvals/{id}`, **so khớp khóa công khai do server trả với khóa trong QR**. Lệch → từ chối và báo sự cố (server đã bị can thiệp).
3. Thiết bị tin cậy ký `(approvalId ‖ signPub ‖ boxPub ‖ nonce)` bằng khóa P-256 của nó và bọc SK tới khóa X25519 của thiết bị mới (sealed box) → `POST .../decision`.
4. Thiết bị mới nhận `sealedSecretKey`, giải ra SK, dẫn xuất KEK và mở rootKey.
5. Email và thông báo tới mọi thiết bị: "Thiết bị mới đã được thêm".

**Không dùng mã so khớp 6 chữ số:** 20 bit có thể bị máy chủ độc hại thử vét cạn khóa cho đến khi trùng. Dự phòng khi không quét được QR: so khớp dấu vân tay 16 ký tự (80 bit).

**Đường dự phòng (không còn thiết bị tin cậy):** OTP email + MFA + SK từ Emergency Kit + **chờ 24 giờ** (`method = delay`); thông báo tới email và mọi phiên còn lại; thiết bị tin cậy hủy được bất cứ lúc nào.

Thiết bị chưa được duyệt không nhận được bất kỳ bản mã nào (`scope = device_approval` không gọi được `/vaults/*`).

---

## 6. Khôi phục (F-20)

Sơ đồ: `diagrams/recovery-flow.mmd`.

| Tình huống | Điều kiện | Kết quả |
|---|---|---|
| A. Mất thiết bị, còn thiết bị khác | Phê duyệt bằng QR | Vào két bình thường |
| B. Mất hết thiết bị, còn mật khẩu chính + SK | OTP + MFA + chờ 24 giờ | Vào két |
| C. Quên mật khẩu chính, còn Recovery Key | Phiên `master_password`: OTP + MFA + chờ 24 giờ → tải `recoveryWrappedRootKey` → giải bằng Recovery Key → đặt mật khẩu mới → rewrap | Vào két; **thu hồi mọi thiết bị và phiên khác** |
| D. Mất mật khẩu chính và Recovery Key | Phiên `account_reset`: OTP + MFA + chờ 72 giờ | **Dữ liệu cũ không thể giải mã.** Két cũ xóa mềm 30 ngày rồi xóa hẳn |
| E. Mất SK nhưng còn thiết bị tin cậy | Xem SK ở Cài đặt (xác thực lại) | Tạo Emergency Kit mới |
| F. Mất MFA | Mã dự phòng, hoặc `mfa_reset` chờ 72 giờ | |

Ghi chú thiết kế:
- Recovery Key tách khỏi SK. Emergency Kit chứa cả hai; **ai có kit + quyền truy cập DB thì giải mã được dữ liệu**. UI phải nói rõ và khuyên lưu kit ngoại tuyến, tách khỏi nơi để mật khẩu. Người dùng được phép từ chối Recovery Key (chấp nhận mất dữ liệu nếu quên mật khẩu).
- Thời gian chờ chống kẻ chiếm email: mọi phiên khôi phục đều thông báo và có nút "Hủy" từ thiết bị tin cậy.
- `account_reset` do kẻ chiếm email thực hiện chỉ gây từ chối dịch vụ (dữ liệu là bản mã), và bị làm chậm 72 giờ + giữ bản mã cũ 30 ngày để người dùng thật kịp phản ứng.

---

## 7. Đồng bộ, ngoại tuyến, xung đột (F-07, F-08, F-18)

Sơ đồ: `diagrams/sync-conflict.mmd`.

- **Cursor đồng bộ là `vaults.change_seq`**, bộ đếm đơn điệu theo két; trigger `trg_items_before_write` gán `change_seq` và `revision` trong cùng transaction. (v1 dùng `revision` theo từng mục làm cursor là sai: hai mục khác nhau có thể cùng revision.) Khóa hàng `vaults` tuần tự hóa ghi trong một két, nên cursor không có "lỗ"; đủ cho két cá nhân.
- `GET /vaults/{id}/changes?cursor=` trả bản mã đã đổi **và tombstone**. Tombstone giữ 90 ngày; cursor cũ hơn → `fullResyncRequired = true`.
- Ghi dữ liệu: `If-Match: <revision>` (header, nhất quán cho PUT và DELETE) + `Idempotency-Key`. Lệch revision → **409** kèm `currentItem` (bản mã); client giải mã, hiển thị S17 cho người dùng chọn: *giữ bản của tôi / giữ bản server / giữ cả hai (tạo bản sao)*. Không tự gộp trường nhạy cảm.
- Idempotency: bảng `idempotency_keys` (24 giờ); cùng khóa + cùng nội dung → trả kết quả cũ; khác nội dung → 422.
- Hàng đợi ngoại tuyến: lưu bản mã đã tạo + khóa idempotency; retry lũy thừa có jitter. Không dùng đồng hồ client để quyết định phiên bản.
- **Phát hiện rollback:** client ghi nhớ `changeSeq` cao nhất đã thấy cho mỗi két; nếu server trả số thấp hơn → cảnh báo (có thể server bị chiếm hoặc khôi phục từ bản sao lưu cũ).
- Lịch sử `item_revisions`: ≤ 10 bản hoặc 90 ngày. Khi xoay vaultKey vì nghi lộ, **xóa** các revision cũ thay vì rewrap.

---

## 8. Tìm kiếm, offline, khóa tự động

- Tìm kiếm chạy cục bộ trên dữ liệu đã giải mã trong RAM; chỉ mục tìm kiếm không được ghi ra đĩa ở dạng rõ. Không gửi từ khóa lên server.
- Cache ngoại tuyến: bản mã trong IndexedDB/SQLite; mở khóa ngoại tuyến cần mật khẩu chính (và SK đã lưu cục bộ).
- Tự khóa mặc định 1 phút ở nền, 5 phút không thao tác; xóa khóa khỏi RAM ở mức thư viện cho phép (JS không bảo đảm zeroization).
- Sinh trắc học (mobile): khóa phiên làm việc được niêm trong Keystore/Keychain với yêu cầu sinh trắc (`biometryCurrentSet` / `setUserAuthenticationRequired`); thay đổi sinh trắc làm khóa mất hiệu lực; bắt buộc nhập lại mật khẩu chính mỗi 14 ngày hoặc sau 5 lần sinh trắc thất bại.
- Clipboard: xóa sau 30 giây (Android 13+ đánh dấu dữ liệu nhạy cảm; iOS dùng `expirationDate`/`localOnly`).

---

## 9. Phía máy chủ (F-11, F-12, F-13)

| Hạng mục | Quy tắc |
|---|---|
| Phân quyền DB | RLS bật và FORCE trên mọi bảng; `SET LOCAL app.user_id` trong mỗi transaction; role ứng dụng không phải owner, không BYPASSRLS; migration dùng role riêng có phê duyệt |
| BOLA/IDOR | Mọi truy vấn qua RLS; 404 (không 403) khi không sở hữu; test tự động cho từng endpoint với hai tài khoản |
| Bí mật phía server | Pepper HMAC và khóa TOTP trong KMS; không nằm trong biến môi trường của image |
| IP | Chỉ lưu `HMAC(key_id, IP)` với khóa xoay vòng; băm không khóa của IPv4 có thể bị đảo ngược |
| Nhật ký | Danh sách trường được phép (allowlist); **không ghi body**; `audit_events.details` ≤ 1 KiB; lưu 180 ngày |
| Egress | API và worker chỉ ra được tới danh sách đích cho phép (KMS, email, object storage) — hạn chế rút dữ liệu khi có mã độc |
| Cảnh báo | Số hàng đọc/giây vượt ngưỡng, truy vấn hàng loạt `vault_items`, đăng nhập thất bại tăng đột biến, `refresh_reuse_detected`, deploy ngoài cửa sổ, **tài khoản mồi (canary)** bị đọc |
| Header | HSTS, CSP nghiêm ngặt, `Cache-Control: no-store` cho API, CORS allowlist |
| Truy cập vận hành | SSO + khóa FIDO2, truy cập đặc quyền theo yêu cầu (JIT, có thời hạn), không SSH vào production, mọi truy cập DB được ghi nhật ký |

---

## 10. Toàn vẹn mã web (F-02)

Máy chủ bị chiếm thì có thể phát mã JS độc hại để lấy mật khẩu chính. Biện pháp (chi tiết ở tài liệu chuỗi cung ứng):

1. Mã web phát hành từ **static host riêng**, tài khoản/dự án cloud riêng, không giữ bí mật của API; domain riêng, DNS và quyền CDN do ít người nắm.
2. CSP nghiêm ngặt + Trusted Types, SRI cho mọi script, không script của bên thứ ba, không inline.
3. Build tái lập; manifest hash của bundle được **ký ngoài băng** (khóa ký cất ngoại tuyến hoặc Sigstore với danh tính FIDO2) và đăng công khai.
4. **Trình giám sát độc lập** (chạy ngoài hạ tầng chính) tải bundle từ nhiều vị trí mỗi 5 phút, so hash với manifest đã ký; lệch → cảnh báo mức SEV1.
5. Service worker ghim phiên bản; cập nhật hiển thị cho người dùng.
6. Khuyến nghị ứng dụng cài đặt (mobile/desktop/extension có ký) cho người dùng rủi ro cao; nêu giới hạn này trong trang bảo mật.

Giới hạn còn lại: người dùng web vẫn phải tin kênh phát hành tại thời điểm tải mã. Không cam kết "máy chủ không thể đọc" cho web theo nghĩa tuyệt đối.

---

## 11. Mobile

Keychain/Keystore cho SK, khóa thiết bị P-256 tạo trong Secure Enclave/StrongBox khi có; chặn ảnh chụp màn hình ở màn hình nhạy cảm và che nội dung trong app switcher; không đưa bí mật vào thông báo, deep link, analytics, crash report; phát hiện root/jailbreak chỉ để cảnh báo, không coi là biện pháp bảo vệ.

---

## 12. Vận hành, sao lưu, khả năng phục hồi

- Sao lưu DB mã hóa tầng hạ tầng, WAL archiving; **mục tiêu RPO ≤ 1 giờ, RTO ≤ 4 giờ** (đề xuất, xác nhận bằng diễn tập quý). Object storage bật versioning + khóa xóa.
- Bản sao lưu server **không thay** bản xuất mã hóa của người dùng (định dạng `.ksvbackup`: header + tham số KDF + AEAD; khóa lấy từ cụm mật khẩu sao lưu riêng hoặc Recovery Key; không dùng lại mật khẩu chính).
- Tách môi trường dev/staging/prod ở cấp tài khoản cloud; staging không có dữ liệu thật.
- Quy trình sự cố: `van-hanh/Runbook_Ung_pho_Su_co.md`.
- Vị trí dữ liệu: ADR-08.

---

## 13. Kiểm thử và test vectors

| Nhóm | Ca bắt buộc |
|---|---|
| Mật mã | Test vectors chéo nền tảng (web, Android, iOS) cho Argon2id, HKDF, AEAD, secretstream; **NFC vs NFD cho mật khẩu tiếng Việt**; sửa 1 bit ciphertext/AAD/nonce → thất bại; không có (key, nonce) trùng trong 10⁶ lần mã hóa thử |
| OPAQUE | Test vectors của RFC 9807; phản hồi giả cho email không tồn tại không phân biệt được bằng thời gian/độ dài; tương thích chéo client/server |
| Khóa | Đổi mật khẩu rewrap đúng; xoay rootKey/vaultKey không đổi payload; khôi phục A–F |
| Phê duyệt thiết bị | Server giả mạo khóa công khai → thiết bị tin cậy phát hiện; thiết bị pending không đọc được bản mã; hủy trong thời gian chờ |
| Phiên | Reuse refresh token → thu hồi họ; chữ ký thiết bị sai → từ chối; thu hồi thiết bị chặn đồng bộ ngay |
| Đồng bộ | Hai thiết bị cùng sửa (409), cursor không bỏ sót dưới ghi đồng thời, tombstone, full resync, idempotency, rollback detection |
| API/DB | BOLA mọi endpoint, RLS (thử bỏ `app.user_id`), rate limit, enumeration, CSRF/CORS |
| Web | XSS, CSP/Trusted Types, SRI, cache dữ liệu nhạy cảm, clickjacking |
| Mobile | Keychain/Keystore, sinh trắc đổi → mất hiệu lực, screenshot/app switcher, clipboard |
| Chuỗi cung ứng | Thử đẩy workflow độc hại không qua duyệt; thử deploy artifact không ký; thử dùng PAT hết hạn |
| Vận hành | Diễn tập khôi phục DB, diễn tập sự cố SEV1 (bàn giấy rồi thực hành), thử cảnh báo canary |

---

## 14. Cổng phát hành bảo mật (security gates)

| Cổng | Điều kiện |
|---|---|
| SG0 (cuối Sprint 0) | Threat model được duyệt; ADR-01…ADR-12 chốt; chính sách GitHub/CI đã bật trên tổ chức |
| SG1 (cuối spike mật mã) | Crypto SDK + OPAQUE đạt test vectors; cryptographer độc lập duyệt giao thức và định dạng |
| SG2 (cuối MVP web + mobile) | Toàn bộ test nhóm API/DB/phiên/đồng bộ đạt; diễn tập khôi phục A–F thành công |
| SG3 (trước beta dữ liệu thật) | Pentest + review mật mã độc lập không còn Critical/High; diễn tập sự cố SEV1 hoàn tất; giám sát toàn vẹn bundle web hoạt động; DPIA và hồ sơ pháp lý xong |
| SG4 (GA) | Beta ổn định, runbook được dùng thử, kế hoạch bug bounty/tiếp nhận lỗ hổng công khai |

Chưa qua SG3: chỉ dùng dữ liệu giả.

---

## 15. Điểm còn mở (cần spike)

1. Thư viện OPAQUE cho NestJS và React Native (ứng viên: các binding của `opaque-ke`); cấu hình KSF.
2. Thư viện HKDF/Argon2id/libsodium chạy ổn trên Hermes/React Native và trên trình duyệt di động (giới hạn bộ nhớ).
3. Cách đóng gói và ký bundle web, hạ tầng giám sát độc lập.
4. Lựa chọn nhà cung cấp email và cấu hình DMARC/SPF/DKIM.
5. Kích thước payload và chiến lược đệm trên thực tế.
