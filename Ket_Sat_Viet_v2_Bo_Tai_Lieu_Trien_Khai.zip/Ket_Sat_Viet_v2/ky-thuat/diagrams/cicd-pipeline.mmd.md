# Sơ đồ CI/CD có cổng kiểm soát

```mermaid
flowchart LR
  DEV[Lập trình viên: SSO + khóa FIDO2, máy được quản lý] --> PR[Pull request vào nhánh bảo vệ]
  PR --> RV{2 reviewer, CODEOWNERS cho crypto, auth, infra, workflows}
  RV --> CHK[Kiểm tra: lint, test, SAST, SCA, secret scan, kiểm tra workflow]
  CHK --> MG[Merge, commit đã ký]
  MG --> BLD[Build trên runner tạm thời, action ghim theo SHA]
  BLD --> ART[Artifact + SBOM + chứng thực provenance + chữ ký]
  ART --> STG[Triển khai staging bằng OIDC, token ngắn hạn]
  STG --> GATE{Cổng production: 2 người duyệt, chờ tối thiểu 30 phút}
  GATE --> VER[Bước triển khai xác minh chữ ký và digest]
  VER --> PRD[Production]
  PRD --> MON[Giám sát: so khớp hash bundle web từ bên ngoài, cảnh báo xuất dữ liệu bất thường, egress allowlist]
```
