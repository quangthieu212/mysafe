# Sơ đồ kiến trúc

```mermaid
flowchart TB
  U[Người dùng] --> W[Web PWA - Next.js]
  U --> M[Mobile - React Native]
  subgraph CL[Vùng client: giữ khóa và giải mã]
    W --> C[Crypto SDK dùng chung: Argon2id, HKDF, XChaCha20-Poly1305, OPAQUE]
    M --> C
  end
  W -. tải mã JS .-> CDN[Static host riêng cho web: CDN, SRI, CSP, bundle ký]
  subgraph SV[Vùng máy chủ: chỉ thấy bản mã]
    GW[API Gateway + WAF + rate limit]
    AUTH[Auth: OPAQUE, MFA, phiên, thiết bị, khôi phục]
    SYNC[Vault + Sync + Attachments]
    WK[Worker: email, dọn dữ liệu, không đọc bản mã]
    KMS[(KMS: pepper HMAC, khóa mã hóa TOTP)]
  end
  C -->|HTTPS, chỉ ciphertext| GW
  GW --> AUTH
  GW --> SYNC
  AUTH --> DB[(PostgreSQL + RLS)]
  SYNC --> DB
  SYNC --> OBJ[(Object storage: ciphertext)]
  AUTH --> KMS
  WK --> DB
  WK --> MAIL[Dịch vụ email: SPF DKIM DMARC]
  subgraph SC[Chuỗi cung ứng]
    GH[GitHub: SSO + khóa FIDO2] --> CI[CI: runner tạm thời, OIDC, provenance]
    CI --> REL{{Cổng duyệt 2 người + xác minh chữ ký}}
  end
  REL --> CDN
  REL --> SV
```
