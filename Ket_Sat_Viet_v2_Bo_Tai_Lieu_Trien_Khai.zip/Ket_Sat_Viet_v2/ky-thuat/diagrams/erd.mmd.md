# Sơ đồ ERD

```mermaid
erDiagram
  USERS ||--o{ USER_MFA : has
  USERS ||--o{ DEVICES : owns
  USERS ||--o{ SESSIONS : opens
  USERS ||--o{ VAULTS : owns
  USERS ||--o{ RECOVERY_KITS : provisions
  USERS ||--o{ RECOVERY_SESSIONS : starts
  USERS ||--o{ AUDIT_EVENTS : generates
  DEVICES ||--o{ SESSIONS : binds
  DEVICES ||--o{ DEVICE_APPROVALS : requests
  VAULTS ||--o{ VAULT_ITEMS : contains
  VAULT_ITEMS ||--o{ ITEM_REVISIONS : versioned
  VAULT_ITEMS ||--o{ ATTACHMENTS : has
  USERS { uuid id PK string email_normalized bytes opaque_record json kdf_params bytes wrapped_root_key int key_version }
  DEVICES { uuid id PK uuid user_id FK bytes sign_public_key bytes box_public_key string status }
  DEVICE_APPROVALS { uuid id PK uuid new_device_id FK string method string status bytes request_nonce bytes sealed_secret_key }
  SESSIONS { uuid id PK uuid device_id FK uuid refresh_family_id bytes refresh_token_hash }
  VAULTS { uuid id PK uuid user_id FK bytes wrapped_vault_key bigint change_seq }
  VAULT_ITEMS { uuid id PK uuid vault_id FK bigint revision bigint change_seq bytes wrapped_item_key bytes nonce bytes ciphertext }
  ITEM_REVISIONS { uuid id PK uuid item_id FK bigint revision }
  ATTACHMENTS { uuid id PK uuid item_id FK string storage_key bytes wrapped_file_key }
  RECOVERY_KITS { uuid id PK uuid user_id FK bytes recovery_wrapped_root_key }
  RECOVERY_SESSIONS { uuid id PK uuid user_id FK string kind string status datetime not_before }
  USER_MFA { uuid id PK uuid user_id FK string kind }
  AUDIT_EVENTS { uuid id PK uuid user_id FK string event_type bytes ip_hmac }
```
