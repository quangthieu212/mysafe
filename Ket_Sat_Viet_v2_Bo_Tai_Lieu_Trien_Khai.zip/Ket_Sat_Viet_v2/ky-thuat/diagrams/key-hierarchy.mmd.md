# Sơ đồ phân cấp khóa

```mermaid
flowchart TD
  MP[Mật khẩu chính, chuẩn hóa NFKC] --> A2[Argon2id với salt theo tài khoản]
  A2 --> H1[HKDF-SHA256: ghép với Secret Key 128 bit]
  SK[Secret Key: tạo trên client, nằm trong Emergency Kit và trên thiết bị tin cậy] --> H1
  H1 -->|info ksv/v1/kek| KEK[KEK]
  H1 -->|info ksv/v1/opaque-password| AUTHS[authSecret: đầu vào OPAQUE]
  KEK -->|bọc| ARK[rootKey ARK 256 bit ngẫu nhiên]
  RK[Recovery Key 256 bit, tùy chọn] -->|bọc bản thứ hai| ARK
  ARK -->|HKDF wrap-vault| VW[Khóa bọc két]
  VW -->|bọc| VK[vaultKey ngẫu nhiên]
  VK -->|HKDF wrap-item| IW[Khóa bọc mục]
  IW -->|bọc| IK[itemKey ngẫu nhiên theo mục]
  IK -->|XChaCha20-Poly1305 + AAD| CT[Payload mục]
  IK -->|bọc| FK[fileKey tệp đính kèm, secretstream]
```
