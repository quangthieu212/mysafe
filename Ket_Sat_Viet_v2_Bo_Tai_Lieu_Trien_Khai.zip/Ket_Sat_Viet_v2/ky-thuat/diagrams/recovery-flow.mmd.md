# Sơ đồ khôi phục truy cập

```mermaid
flowchart TD
  S[Mất truy cập] --> Q1{Còn thiết bị tin cậy?}
  Q1 -->|Có| A[Đăng nhập thiết bị mới, thiết bị tin cậy phê duyệt bằng QR]
  Q1 -->|Không| Q2{Còn mật khẩu chính và Secret Key?}
  Q2 -->|Có| B[Đăng nhập thiết bị mới: OTP email, MFA, chờ 24 giờ, thông báo mọi nơi]
  Q2 -->|Không| Q3{Còn Recovery Key?}
  Q3 -->|Có| C[Phiên khôi phục: OTP, MFA, chờ 24 giờ, thiết bị cũ có thể hủy]
  C --> C2[Giải rootKey bằng Recovery Key, đặt mật khẩu chính mới, rewrap, thu hồi thiết bị khác]
  Q3 -->|Không| D[Đặt lại tài khoản: OTP, MFA, chờ 72 giờ]
  D --> D2[Két cũ xóa mềm 30 ngày rồi xóa hẳn. Dữ liệu cũ không thể giải mã]
  A --> OK[Vào két]
  B --> OK
  C2 --> OK
  D2 --> NEW[Két mới, trống]
```
