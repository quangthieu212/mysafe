# Sơ đồ đồng bộ và xung đột

```mermaid
sequenceDiagram
  participant A as Thiết bị A
  participant S as Sync API
  participant D as Database
  participant B as Thiết bị B
  A->>S: PUT item If-Match 4, Idempotency-Key k1
  S->>D: UPDATE WHERE revision = 4, trigger gán revision 5 và changeSeq 120
  S-->>A: 200 revision 5
  B->>S: PUT item If-Match 4, Idempotency-Key k2
  S-->>B: 409 kèm currentItem revision 5
  B->>B: Giải mã bản hiện hành, so sánh với bản đang sửa
  B->>B: Người dùng chọn: giữ bản của tôi, giữ bản server hoặc giữ cả hai
  B->>S: PUT item If-Match 5, Idempotency-Key k3
  S-->>B: 200 revision 6
  A->>S: GET changes cursor 120
  S-->>A: các thay đổi sau 120, gồm cả tombstone
  A->>A: Ghi nhớ changeSeq cao nhất. Nếu server trả số nhỏ hơn thì cảnh báo rollback
```
