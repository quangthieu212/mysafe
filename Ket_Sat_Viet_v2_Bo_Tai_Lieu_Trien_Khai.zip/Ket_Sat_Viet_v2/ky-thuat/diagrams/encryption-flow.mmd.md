# Sơ đồ đăng ký và mã hóa

```mermaid
sequenceDiagram
  actor U as Người dùng
  participant App as Ứng dụng client
  participant Cry as Crypto SDK
  participant API as API Server
  participant DB as PostgreSQL
  U->>App: Nhập email
  App->>API: POST /auth/email-challenges
  API-->>U: OTP 8 chữ số qua email
  U->>App: Nhập OTP
  App->>API: POST /auth/email-challenges/verify
  API-->>App: emailProof
  U->>App: Tạo mật khẩu chính
  App->>Cry: Sinh Secret Key, rootKey, Recovery Key bằng CSPRNG
  App->>Cry: Argon2id rồi HKDF ra KEK và authSecret
  App->>API: register/start với RegistrationRequest của OPAQUE
  API-->>App: RegistrationResponse
  App->>Cry: Hoàn tất OPAQUE bằng authSecret
  App->>API: register/finish gồm record, wrappedRootKey, recoveryWrappedRootKey, két, thiết bị
  API->>DB: Lưu dữ liệu không có khóa hay mật khẩu
  App->>U: Hiển thị Emergency Kit và bắt xác nhận đã lưu
  U->>App: Tạo mục mới
  App->>Cry: itemKey ngẫu nhiên, nonce 24 byte, AEAD với AAD
  App->>API: POST items gồm ciphertext, wrappedItemKey, Idempotency-Key
  API->>DB: Kiểm tra quyền (RLS), ghi bản mã, gán changeSeq
  API-->>App: revision, changeSeq
```
