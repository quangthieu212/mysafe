# Sơ đồ phê duyệt thiết bị

```mermaid
sequenceDiagram
  actor U as Người dùng
  participant N as Thiết bị mới
  participant S as API Server
  participant T as Thiết bị tin cậy
  U->>N: Đăng nhập: email, mật khẩu chính
  N->>S: OPAQUE login start và finish
  S-->>N: mfa_required
  N->>S: mfa/verify
  S-->>N: device_approval_required và pendingToken
  N->>N: Sinh khóa thiết bị P-256 và X25519, nonce 32 byte
  N->>S: POST devices/approvals
  N->>N: Hiển thị QR chứa khóa công khai và nonce
  S-->>T: Thông báo yêu cầu thiết bị mới
  U->>T: Mở màn hình phê duyệt và quét QR
  T->>S: GET approvals, lấy khóa công khai lưu trên server
  T->>T: So khớp với QR. Lệch nghĩa là server đã bị can thiệp, từ chối
  T->>T: Ký phê duyệt, bọc Secret Key tới khóa X25519 của thiết bị mới
  T->>S: POST decision approve
  S-->>N: status approved, sealedSecretKey
  N->>N: Giải Secret Key, dẫn xuất KEK, mở rootKey
  S-->>U: Email và thông báo: thiết bị mới đã được thêm
```
