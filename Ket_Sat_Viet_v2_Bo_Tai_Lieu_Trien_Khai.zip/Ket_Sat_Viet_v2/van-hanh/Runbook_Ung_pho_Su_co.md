# Runbook ứng phó sự cố — Két Sắt Việt v2.0

Cập nhật 26/11/2026 | Dùng cho SEV1–SEV3. In và diễn tập trước cổng SG3.

> **Lưu ý pháp lý:** các mốc thời gian báo cáo dưới đây dựa trên việc tra cứu khung pháp luật hiện hành (Luật Bảo vệ dữ liệu cá nhân số 91/2025/QH15, hiệu lực 01/01/2026; Nghị định 356/2025/NĐ-CP hướng dẫn thi hành, thay Nghị định 13/2023; Nghị định 330/2026/NĐ-CP về xử phạt, hiệu lực 19/08/2026). Nghĩa vụ báo cáo trong **72 giờ** áp dụng khi sự cố thuộc diện phải thông báo; điều kiện chính xác và đầu mối nhận báo cáo phải được **tư vấn pháp lý xác nhận** trước khi dùng. Không thay thế ý kiến luật sư.

---

## 1. Mức độ sự cố

| Mức | Ví dụ | Phản hồi | Cô lập | Thông báo lãnh đạo |
|---|---|---|---|---|
| **SEV1** | Nghi ngờ mã độc đã lên production/CDN; tài khoản lập trình viên bị chiếm; hash bundle web lệch; canary bị đọc; DB/object storage bị xuất; lộ khóa KMS/ký | Ngay, 24/7 | ≤ 1 giờ | ≤ 15 phút |
| **SEV2** | Credential stuffing quy mô lớn; lộ OTP/token cho nhóm người dùng; phụ thuộc bị đầu độc chưa lên production | ≤ 1 giờ | ≤ 4 giờ | ≤ 1 giờ |
| **SEV3** | Lỗi cấu hình không có bằng chứng bị khai thác; lỗ hổng mức Medium được báo cáo | Trong ngày làm việc | ≤ 3 ngày | Báo cáo tuần |

## 2. Vai trò

| Vai trò | Nhiệm vụ |
|---|---|
| Chỉ huy sự cố (IC) | Quyết định, giữ dòng thời gian, phân công |
| Trưởng kỹ thuật | Điều tra, cô lập, xoay khóa |
| Phụ trách mật mã/bảo mật | Đánh giá ảnh hưởng tới khóa, quyết định xoay khóa người dùng |
| Truyền thông | Thông báo người dùng, trang trạng thái, báo chí |
| Pháp lý / DPO | Xác định nghĩa vụ báo cáo, soạn hồ sơ, làm việc với cơ quan chuyên trách |
| Người ghi chép | Nhật ký thời gian, bằng chứng |

Danh bạ trực (hai người cho mỗi vai trò, kèm số điện thoại ngoài hệ thống chính) được lưu ngoại tuyến và trong kênh liên lạc dự phòng không phụ thuộc hạ tầng bị nghi ngờ.

## 3. Mốc thời gian chung

| Thời điểm | Việc phải xong |
|---|---|
| T0 | Phát hiện/nghi ngờ; mở sự cố, chỉ định IC |
| T+15 phút | Phân loại SEV; huy động đội; thông báo lãnh đạo (SEV1) |
| T+1 giờ | Cô lập ban đầu (khóa tài khoản, thu hồi token, đóng đường deploy) |
| T+4 giờ | Phạm vi sơ bộ; quyết định xoay khóa; bảo toàn bằng chứng |
| T+24 giờ | Đánh giá dữ liệu bị ảnh hưởng; dự thảo thông báo; pháp lý đánh giá nghĩa vụ |
| **≤ T+72 giờ** | Thông báo cơ quan chuyên trách và chủ thể dữ liệu **nếu thuộc diện phải thông báo** (nếu trễ, ghi rõ lý do) |
| T+5 ngày làm việc | Báo cáo sau sự cố (không đổ lỗi), kế hoạch khắc phục |
| T+30 ngày | Xác nhận các hạng mục khắc phục đã xong |

Thời điểm phát hiện được tính từ khi có dấu hiệu đáng tin cậy đầu tiên, ghi trong nhật ký.

---

## 4. Playbook

### P1 — Tài khoản lập trình viên/GitHub bị chiếm (kịch bản 1Password)

1. **Cô lập (≤ 1 giờ):** vô hiệu hóa tài khoản và mọi token/PAT/khóa SSH của người đó; thu hồi phiên SSO; tạm khóa quyền ghi của tổ chức nếu chưa rõ phạm vi.
2. **Đóng đường triển khai:** tắt tự động deploy production; chuyển environment production sang "chặn cho đến khi IC cho phép".
3. **Xác định phạm vi:** log kiểm toán GitHub (đăng nhập, token, push, tạo/sửa workflow, force-push, clone), log CI, log cloud (vai trò OIDC được dùng). Liệt kê commit/workflow/tag do tài khoản đó tạo trong cửa sổ nghi ngờ.
4. **Kiểm tra artifact:** đối chiếu mọi bản phát hành trong cửa sổ nghi ngờ với provenance và chữ ký; bản nào không khớp coi là độc hại.
5. **Khôi phục sạch:** build lại từ commit đã được 2 người duyệt trước cửa sổ nghi ngờ, trên runner mới; triển khai lại backend và static host; so hash bundle web với manifest ký.
6. **Xoay bí mật:** mọi bí mật mà CI/tài khoản đó có thể đọc (environment secret, vai trò cloud, khóa KMS dùng trong CI, khóa ký nếu nằm trong CI); thu hồi và tạo lại; xem xét xoay pepper HMAC (làm mất hiệu lực OTP/mã dự phòng cũ — chấp nhận được).
7. **Xác định dữ liệu bị đọc:** log truy vấn DB/object storage trong cửa sổ nghi ngờ; kiểm tra canary; xác định bảng/cột/người dùng liên quan.
8. **Hậu kiểm người dùng:** nếu có dấu hiệu lộ metadata hoặc token → P4; nếu có mã độc chạm đường giải mã web → P2.
9. Thông báo theo mục 5 nếu có dữ liệu cá nhân bị ảnh hưởng.

### P2 — Mã độc trên production hoặc JS web bị sửa

1. Dừng phát hành; chuyển static host về bản sạch gần nhất đã xác minh hoặc hiển thị trang bảo trì; vô hiệu hóa cache CDN.
2. Xác định khoảng thời gian bundle bị sửa (từ giám sát hash và log CDN) và số phiên đã tải.
3. **Giả định mật khẩu chính của người dùng đã tải bản độc hại có thể bị lộ.** Quyết định bắt buộc đổi mật khẩu chính và xoay Secret Key cho nhóm này; phụ trách mật mã quyết định xoay rootKey/vaultKey (xoay vaultKey chỉ rewrap itemKey).
4. Thu hồi toàn bộ phiên của nhóm bị ảnh hưởng; yêu cầu xác thực lại + MFA.
5. Thông báo người dùng kèm hướng dẫn cụ thể; xem P7 nếu nguyên nhân là phụ thuộc.

### P3 — Lộ DB hoặc object storage

1. Xác định phạm vi (bảng, snapshot, thời điểm); thu hồi thông tin xác thực truy cập; tạo bản chụp để điều tra.
2. Dữ liệu bị lộ gồm bản mã, record OPAQUE, kdf_params, `wrapped_root_key`, email, metadata. Đánh giá: kẻ tấn công **không** dò được mật khẩu offline nếu không có Secret Key; nhưng email và metadata là dữ liệu cá nhân → nghĩa vụ thông báo.
3. Xoay pepper HMAC và khóa mã hóa TOTP nếu có nguy cơ; yêu cầu người dùng có thể bị ảnh hưởng xem lại MFA.
4. Kiểm tra Emergency Kit: sự cố này không làm lộ kit; nhắc người dùng đừng chia sẻ kit.

### P4 — Lộ OTP/token email hoặc dấu hiệu chiếm tài khoản

1. Vô hiệu hóa mọi `email_challenges` chưa dùng; xoay pepper nếu OTP có thể bị lộ.
2. Tăng cường: tạm bắt buộc MFA cho đăng nhập thiết bị mới; kéo dài thời gian chờ khôi phục.
3. Gửi thông báo tới email và thiết bị của người dùng bị ảnh hưởng; yêu cầu xem trang Sự kiện bảo mật (S19).
4. Theo dõi `recovery_started`, `device_approval_requested` bất thường; hủy phiên đáng ngờ.
5. Cảnh báo phishing: kẻ tấn công có danh sách email người dùng có thể gửi thư giả mạo.

### P5 — Lộ khóa ký phát hành hoặc khóa KMS

1. Thu hồi khóa; đăng thông báo thu hồi công khai; phát hành manifest mới ký bằng khóa mới; cập nhật khóa tin cậy trong client (cần phát hành app) và giám sát.
2. Coi mọi bản phát hành ký bằng khóa cũ trong cửa sổ nghi ngờ là chưa tin cậy; xác minh lại bằng build tái lập.
3. Với khóa KMS: xoay, giải mã/mã hóa lại bí mật TOTP bằng khóa mới.

### P6 — Credential stuffing / tấn công hàng loạt

1. Bật giới hạn nghiêm hơn và thử thách bổ sung; chặn dải IP/ASN; không tiết lộ tài khoản nào bị trúng.
2. Thông báo người dùng có nhiều lần thất bại; khuyến nghị bật WebAuthn.
3. Vì OPAQUE + Secret Key, mật khẩu rò rỉ từ nơi khác không đủ để đăng nhập thiết bị mới; kiểm tra tỷ lệ thành công bất thường trên thiết bị đã biết.

### P7 — Phụ thuộc/vendor bị đầu độc

1. Xác định phiên bản và thời điểm đưa vào; `git bisect` lockfile; kiểm tra SBOM để biết artifact nào chứa nó.
2. Nếu đã lên production → xử lý như P1/P2; nếu chưa → khóa phiên bản, thay thế, ghi nhận.
3. Rà soát bí mật có mặt trong CI khi phiên bản đó chạy; xoay nếu cần.

---

## 5. Mẫu thông báo người dùng (tiếng Việt)

> **Tiêu đề:** Thông báo về sự cố bảo mật của Két Sắt Việt
>
> **Chuyện gì đã xảy ra:** Ngày [ngày], chúng tôi phát hiện [mô tả ngắn, trung thực]. Chúng tôi đã [hành động cô lập] lúc [giờ].
>
> **Dữ liệu bị ảnh hưởng:** [Liệt kê cụ thể: email, thời điểm tạo tài khoản…]. **Nội dung két của bạn [không bị ảnh hưởng / đang được đánh giá] vì được mã hóa trên thiết bị của bạn.** [Nếu P2: nêu rõ rằng mật khẩu chính có thể bị lộ khi dùng phiên bản web trong khoảng …]
>
> **Chúng tôi đã làm gì:** [thu hồi phiên, xoay khóa, thuê chuyên gia độc lập…].
>
> **Bạn cần làm gì:** [1) Đổi mật khẩu chính (nếu P2) 2) Kiểm tra mục Sự kiện bảo mật 3) Cảnh giác email giả mạo — chúng tôi **không bao giờ** hỏi mật khẩu chính, Secret Key hay mã OTP qua email hoặc điện thoại 4) Bật khóa bảo mật WebAuthn].
>
> **Liên hệ:** [kênh hỗ trợ chính thức]. Chúng tôi sẽ cập nhật tại [trang trạng thái] khi có thông tin mới.

Nguyên tắc: nói rõ điều đã biết/chưa biết, không hứa "không bao giờ bị lộ", không chờ điều tra xong hoàn toàn mới thông báo.

## 6. Bằng chứng và sau sự cố

- Chụp bản sao nhật ký (GitHub, CI, cloud, DB, CDN) vào kho chỉ-ghi trước khi xoay khóa hoặc dựng lại.
- Báo cáo sau sự cố trong 5 ngày làm việc: dòng thời gian, nguyên nhân gốc, kiểm soát nào hoạt động/không, việc cần làm kèm người chịu trách nhiệm và hạn.
- Cập nhật threat model và checklist SG; công bố tóm tắt cho người dùng.

## 7. Diễn tập

| Hoạt động | Tần suất |
|---|---|
| Diễn tập bàn giấy P1 (chiếm tài khoản dev), P2 (JS bị sửa) | Trước SG3, sau đó mỗi 6 tháng |
| Kiểm tra kênh liên lạc dự phòng và danh bạ trực | Mỗi quý |
| Diễn tập phục hồi DB | Mỗi quý |
| Thử cảnh báo canary và giám sát hash bundle | Mỗi tháng |
