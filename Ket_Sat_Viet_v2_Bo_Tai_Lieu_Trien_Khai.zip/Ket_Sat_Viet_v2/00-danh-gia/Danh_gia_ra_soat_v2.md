# Đánh giá lại toàn bộ dự án Két Sắt Việt và danh sách thay đổi v1.0 → v2.0

Ngày 26/11/2026 | Đối tượng rà soát: bộ tài liệu v1.0 (28/10/2026, 18 tệp) | Cơ sở: đọc toàn bộ tài liệu, đối chiếu với diễn biến sự cố 1Password (25/11/2026, theo các bài báo; chưa đối chiếu bài công bố gốc), RFC 9807 và khung pháp lý bảo vệ dữ liệu cá nhân hiện hành.

## 1. Kết luận

Nền tảng mật mã của v1 hợp lý (khóa dẫn xuất bằng KDF, AEAD, tìm kiếm cục bộ, không hứa "không thể bị lộ"). Điểm yếu nằm ở **ba nhóm**:

1. **Giả định máy chủ và kênh phát hành an toàn hơn thực tế.** Sự cố 1Password cho thấy đường tấn công qua tài khoản lập trình viên → CI/CD → backend bỏ qua toàn bộ mật mã của sản phẩm. v1 chỉ có SAST/SCA/SBOM chung chung.
2. **Phần then chốt còn để trống**: giao thức xác thực (`proof` placeholder), token email, phê duyệt thiết bị, khôi phục.
3. **Sai sót thiết kế và không nhất quán giữa các tài liệu** (cursor đồng bộ, hợp đồng API, phân cấp khóa, RLS).

v2 xử lý cả ba. Mọi chỗ còn mở được liệt kê trong mục 5.

## 2. Phát hiện và cách xử lý

Mức: **C** Nghiêm trọng, **H** Cao, **M** Trung bình, **L** Thấp.

| ID | Mức | Phát hiện ở v1 | Xử lý ở v2 | Nơi cập nhật |
|---|---|---|---|---|
| F-01 | C | Không có kiểm soát cho tài khoản lập trình viên, GitHub, CI/CD; kênh phát hành không nằm trong threat model | Bộ kiểm soát A–G (FIDO2, ruleset, OIDC, cổng duyệt, chữ ký, egress, canary); đưa vào cổng SG0 | `an-ninh/Kiem_soat_Chuoi_Cung_ung_va_CICD.md`, ADR-12 |
| F-02 | C | Mã JS web do server phân phối; §6.2 chỉ thừa nhận, không có biện pháp | Static host riêng, SRI, CSP/Trusted Types, bundle ký, giám sát hash độc lập | TD §10, ADR-04 |
| F-03 | H | KEK chỉ từ mật khẩu chính; server giữ `wrapped_root_key` + verifier → lộ DB là dò mật khẩu offline | Secret Key 128 bit trộn vào KEK và authSecret | TD §3, ADR-02 |
| F-04 | H | Xác thực chưa chốt; OpenAPI dùng `proof` placeholder | OPAQUE (RFC 9807) với phản hồi giả; thêm cổng review độc lập | TD §4, ADR-01 |
| F-05 | H | Token xác minh/khôi phục qua email chưa được thiết kế (không có bảng, không có quy tắc) | OTP 8 chữ số nhập trong app; chỉ lưu HMAC; 10 phút; 5 lần thử; gắn `clientNonce`; không link | `email_challenges`, ADR-06 |
| F-06 | H | Khóa công khai thiết bị do server lưu, có thể bị thay nếu server bị chiếm; "phê duyệt thiết bị" chỉ ghi một dòng | QR + chữ ký + SK niêm; không dùng mã 6 chữ số; đường dự phòng chờ 24 giờ | TD §5, ADR-05, `device_approvals` |
| F-07 | H | `revision` theo từng mục dùng làm cursor đồng bộ — không đúng; hai mục khác nhau có thể cùng revision | `vaults.change_seq` + trigger gán trong transaction; tombstone; full resync | `schema.sql`, TD §7 |
| F-08 | M | OpenAPI v1 đặt `expectedRevision` trong body cho ghi mục nhưng dùng header `If-Match` cho DELETE; kế hoạch API lại mô tả PUT kèm `If-Match` | Thống nhất `If-Match` header cho PUT/DELETE; 409 kèm `currentItem` | `openapi.yaml`, TD §7 |
| F-09 | M | API khác nhau giữa kế hoạch (`/v1/auth/login/start`, `/vault/sync`), TD (`/auth/login`, `/sync/changes`) và OpenAPI; nhiều endpoint 200 trả schema `Error`; mọi endpoint liệt kê 409; thiếu `Idempotency-Key` | OpenAPI viết lại, 44 thao tác, kiểm tra không lỗi tham chiếu; một nguồn sự thật | `openapi.yaml` |
| F-10 | M | Phân cấp khóa không đồng nhất (rootKey vs vaultKey vs "khóa dữ liệu"); thiếu cột `wrapped_item_key` | rootKey → vaultKey → itemKey → payload; cột đầy đủ | TD §3, `schema.sql` |
| F-11 | H | RLS chỉ là ghi chú; `vault_items` không có `user_id` → rủi ro IDOR/BOLA | RLS bật và FORCE; `user_id` khử chuẩn hóa; 3 role DB; 404 thay 403 | `schema.sql`, TD §9 |
| F-12 | M | `audit_events.ip_hash`: băm không khóa của IPv4 đảo ngược được | `ip_hmac` với khóa KMS xoay vòng | `schema.sql` |
| F-13 | M | `audit_events.details jsonb` tự do dễ lọt bí mật | Allowlist `event_type`, `details` ≤ 1 KiB, log theo allowlist | `schema.sql`, TD §9 |
| F-14 | M | Xoay khóa/đổi mật khẩu cần mã hóa lại dữ liệu | Khóa phong bì nhiều tầng: đổi mật khẩu chỉ rewrap rootKey; xoay vaultKey rewrap itemKey | TD §3 |
| F-15 | H | Chỉ có "runbook sự cố" trong điều kiện Go/No-Go; không có phát hiện, playbook, mốc pháp lý. Tài liệu nhắc khung pháp lý cũ | Runbook với 7 playbook, mẫu thông báo, mốc 72 giờ; cập nhật căn cứ pháp lý (Luật 91/2025/QH15, NĐ 356/2025, NĐ 330/2026) | `van-hanh/`, PRD §8 |
| F-16 | M | Phiên dùng bearer JWT; không gắn thiết bị; không có cơ chế phát hiện tái dùng | Xoay refresh + phát hiện tái dùng + chữ ký khóa thiết bị + xác thực lại ≤ 5 phút | TD §4.3, ADR-07 |
| F-17 | M | MFA chỉ được nhắc, không thiết kế | WebAuthn/TOTP/mã dự phòng; `user_mfa`; `mfa_reset` có chờ | TD §4.4, `schema.sql` |
| F-18 | L | Có nhắc idempotency nhưng không có nơi lưu | `idempotency_keys` (24 giờ), 422 khi trùng khóa khác nội dung | `schema.sql`, TD §7 |
| F-19 | M | Lịch 20 tuần lạc quan khi chưa tính hardening CI, spike OPAQUE, kiểm toán | 26 tuần, cổng SG0–SG4, DevOps toàn thời gian từ đầu | PRD §9–10, Backlog |
| F-20 | M | Recovery Key/kit: chưa nói rõ rủi ro kit bị đánh cắp; "reset tài khoản" chưa định nghĩa | Kịch bản A–F; kit = SK + Recovery Key, nêu rõ rủi ro; reset chờ 72 giờ, giữ bản mã cũ 30 ngày | TD §6 |
| F-21 | M | Danh sách "quyết định cần chốt" còn mở (auth, hạ tầng, khôi phục, offline…) | 12 ADR | `Quyet_dinh_kien_truc_ADR.md` |
| F-22 | L | Tệp đính kèm: giới hạn, chunk, trạng thái chưa đủ | secretstream 1 MiB/chunk, ≤ 10 MiB, `attachments.state`, hoàn tất có SHA-256 | TD §3.3, `schema.sql`, `openapi.yaml` |
| F-23 | L | Wireframe là khung chung, không phản ánh từng màn hình | 24 màn hình có thành phần cụ thể, sinh từ bảng màn hình | `ui/` |
| F-24 | M | Vị trí dữ liệu chưa quyết | Đề xuất đặt tại Việt Nam; cần xác nhận pháp lý | ADR-08 |
| F-25 | M | Tiếng Việt: mật khẩu có dấu có thể khác nhau giữa dạng dựng sẵn và tổ hợp, làm hỏng KEK trên thiết bị khác | Chuẩn hóa NFKC trước KDF + test NFC/NFD bắt buộc | TD §3.1, §13 |
| F-26 | L | Phát hiện rollback/tráo bản mã bởi server chưa được xử lý | Revision trong AAD + `changeSeq` cao nhất lưu ở client | TD §3.3, §7 |

## 3. Cái giữ nguyên từ v1

Tìm kiếm cục bộ; không lưu CVV/PIN/OTP giao dịch; không hứa "không thể lộ"; Argon2id; AEAD với AAD ràng buộc ngữ cảnh; PostgreSQL + object storage chỉ bản mã; React Native + Next.js + NestJS; không tự viết thuật toán; tiêu chí Go/No-Go nghiêm ngặt.

## 4. Đánh đổi của v2

- **Thêm Secret Key** làm trải nghiệm đăng ký/thiết bị mới nặng hơn; bù bằng QR, lưu trong Keychain/Keystore, và UX Emergency Kit cẩn thận.
- **Bộ khôi phục chứa cả SK lẫn Recovery Key**: ai giữ kit + có DB sẽ giải mã được. Người dùng được phép từ chối Recovery Key.
- **Web vẫn có giới hạn bản chất** (tin kênh phát hành khi tải mã). Giảm bằng giám sát, không loại trừ.
- **Thêm chi phí hạ tầng và quy trình**: static host riêng, giám sát bundle, phát hành 2 người, thời gian chờ khôi phục.
- **Lịch dài hơn ≈ 6 tuần** so với v1.

## 5. Còn mở sau bản này

1. Thư viện OPAQUE và Argon2id trên React Native/Hermes, trên trình duyệt di động: **chưa được thử** — chỉ là ứng viên.
2. Phần ghép nối OPAQUE + KDF (KSF, ràng buộc ngữ cảnh) và định dạng envelope cần **cryptographer độc lập duyệt**.
3. Nghĩa vụ pháp lý cụ thể (điều kiện phải báo cáo, đầu mối nhận, chuyển dữ liệu ra nước ngoài): **cần luật sư xác nhận**; tài liệu chỉ dựa trên tra cứu công khai.
4. Các sơ đồ dạng flowchart (kiến trúc, phân cấp khóa, khôi phục, CI/CD) chưa được render thử trong môi trường này; sơ đồ tuần tự và ERD đã qua kiểm tra cú pháp.
5. `schema.sql` chưa được chạy trên PostgreSQL thật (môi trường không có), cần chạy thử trong Sprint 2; OpenAPI đã kiểm tra tham chiếu và trùng lặp nhưng chưa qua bộ lint chuyên dụng.
6. Ngân sách, SLA, số lượng người dùng mục tiêu, nhà cung cấp hạ tầng/email: chưa có dữ liệu.
7. Chi tiết sự cố 1Password lấy từ báo chí; nhiều chi tiết (cách chiếm tài khoản, số khách hàng ảnh hưởng) chính hãng chưa công bố hoặc chưa được xác nhận.
