# Két Sắt Việt — Bộ tài liệu triển khai v2.0 (Markdown, UTF-8)

Cập nhật 26/11/2026. Thay thế bộ v1.0 (28/10/2026). Toàn bộ tài liệu là `.md` mã hóa **UTF-8** (không phải mã hóa bảo mật).

## Thứ tự đọc đề xuất

1. `00-danh-gia/Danh_gia_ra_soat_v2.md` — vì sao thay đổi: 26 phát hiện (F-01…F-26) và cách xử lý.
2. `ke-hoach/Ke_hoach_va_Dac_ta_He_thong_Ket_Sat_Viet.md` — PRD/SRS: mục tiêu, phạm vi, yêu cầu, lộ trình 26 tuần, pháp lý.
3. `ky-thuat/Quyet_dinh_kien_truc_ADR.md` — 12 quyết định đã chốt (OPAQUE, Secret Key, bộ mật mã, phát hành web…).
4. `ky-thuat/Technical_Design_Ket_Sat_Viet.md` — thiết kế kỹ thuật chi tiết.
5. `an-ninh/Threat_Model.md` và `an-ninh/Kiem_soat_Chuoi_Cung_ung_va_CICD.md` — mối đe dọa và kiểm soát (bài học từ sự cố 1Password).
6. `van-hanh/Runbook_Ung_pho_Su_co.md` — 7 playbook, mốc 72 giờ, mẫu thông báo.
7. `trien-khai/Backlog_va_Lo_trinh_Trien_khai.md` — epic, câu chuyện, sprint, Definition of Done, checklist cổng.

## Cấu trúc

```
README.md
00-danh-gia/        Đánh giá và bảng truy vết thay đổi
ke-hoach/           PRD + SRS
ky-thuat/
  Technical_Design_Ket_Sat_Viet.md
  Quyet_dinh_kien_truc_ADR.md
  api/openapi.yaml.md           (bản đọc; tệp chạy được ở ban-goc-chay-duoc/)
  database/schema.sql.md
  diagrams/*.mmd.md             8 sơ đồ Mermaid
  ui/screen-inventory.csv.md, wireframes.html.md
an-ninh/            Threat model, chuỗi cung ứng/CI-CD
van-hanh/           Runbook sự cố
trien-khai/         Backlog và lộ trình
ban-goc-chay-duoc/  openapi.yaml, schema.sql, wireframes.html, screen-inventory.csv, diagrams/*.mmd
```

Các tệp `.md` chứa API/SQL/HTML chỉ để đọc; muốn dùng với Swagger, PostgreSQL hoặc trình duyệt, lấy tệp gốc trong `ban-goc-chay-duoc/`. Sơ đồ Mermaid cần Markdown Preview có hỗ trợ Mermaid.

## Những thay đổi chính so với v1

- Secret Key 128 bit trộn vào khóa dẫn xuất; OPAQUE (RFC 9807) cho xác thực; OTP nhập trong ứng dụng thay cho liên kết email.
- Phê duyệt thiết bị bằng QR + chữ ký; khôi phục A–F có thời gian chờ và thông báo.
- Chuỗi cung ứng/CI-CD là yêu cầu bắt buộc (cổng SG0); giám sát toàn vẹn mã web.
- Sửa cursor đồng bộ (`change_seq`), thống nhất hợp đồng API (44 thao tác), thêm RLS, idempotency, MFA, phiên gắn thiết bị.
- Chuẩn hóa NFKC cho mật khẩu có dấu tiếng Việt.
- Lịch 26 tuần với cổng SG0–SG4; cập nhật căn cứ pháp lý (Luật 91/2025/QH15, NĐ 356/2025/NĐ-CP, NĐ 330/2026/NĐ-CP).

## Lưu ý bảo mật và giới hạn

Đây là bản thiết kế **chưa kiểm toán bảo mật**. Không lưu dữ liệu thật trước khi qua cổng SG3. Các điểm cần xử lý trước khi tin cậy được liệt kê ở `00-danh-gia/Danh_gia_ra_soat_v2.md` mục 5: spike thư viện OPAQUE/Argon2id trên React Native, review mật mã độc lập phần ghép nối, xác nhận pháp lý, chạy thử `schema.sql` trên PostgreSQL thật, render thử các sơ đồ flowchart. Chi tiết sự cố 1Password lấy từ báo chí và chưa đối chiếu bài công bố gốc của hãng.
