# Backlog và lộ trình triển khai — Két Sắt Việt v2.0

Cập nhật 26/11/2026 | 13 sprint × 2 tuần ≈ 26 tuần (ước tính). Ưu tiên: P0 bắt buộc cho MVP, P1 nên có, P2 sau.

## 1. Cấu trúc kho mã (monorepo)

```
apps/web            Next.js PWA (không SSR dữ liệu két)
apps/mobile         React Native
services/api        NestJS: module auth (ksv_auth), vault (ksv_app), worker (ksv_worker)
packages/crypto     Crypto SDK dùng chung (CODEOWNERS: người phụ trách mật mã)
packages/contracts  OpenAPI + kiểu sinh tự động
packages/testvectors Test vectors chéo nền tảng
infra/              Hạ tầng dưới dạng mã (CODEOWNERS: DevOps)
monitor/            Giám sát toàn vẹn bundle web (chạy ngoài hạ tầng chính)
docs/               Tài liệu này
.github/workflows/  CODEOWNERS: DevOps + bảo mật
```

## 2. Epic và câu chuyện

### E0 — Nền tảng an toàn (Sprint 0–1)

| ID | Câu chuyện | Ưu tiên | Nghiệm thu |
|---|---|---|---|
| E0-1 | Bật SSO + FIDO2 cho toàn tổ chức GitHub | P0 | 100% thành viên; thử đăng nhập TOTP bị từ chối |
| E0-2 | Ruleset nhánh, CODEOWNERS, commit ký, secret scanning + push protection | P0 | Thử bypass thất bại |
| E0-3 | CI: action ghim SHA, quyền tối thiểu, runner tạm thời, OIDC | P0 | Không có khóa cloud tĩnh |
| E0-4 | Environment staging/production với người duyệt + chờ | P0 | Deploy production cần 2 người |
| E0-5 | Build sinh SBOM, provenance, chữ ký; bước deploy xác minh | P0 | Artifact không ký bị chặn |
| E0-6 | Đẩy log GitHub/CI/cloud vào giám sát; cảnh báo | P0 | Cảnh báo thử nghiệm được nhận ≤ 15 phút |
| E0-7 | Threat model được duyệt; ADR chốt | P0 | SG0 |
| E0-8 | Chọn bên pentest/review mật mã độc lập, đặt lịch | P0 | Có hợp đồng hoặc lịch giữ chỗ |

### E1 — Mật mã và xác thực (Sprint 1–3)

| ID | Câu chuyện | Ưu tiên | Nghiệm thu |
|---|---|---|---|
| E1-1 | Crypto SDK: Argon2id, HKDF, XChaCha20-Poly1305, secretstream, sealed box | P0 | Test vectors đạt trên web/Android/iOS |
| E1-2 | Chuẩn hóa NFKC và test NFC/NFD tiếng Việt | P0 | Cùng KEK từ hai dạng |
| E1-3 | Định dạng envelope, AAD, version, đệm payload | P0 | Sửa 1 bit → thất bại |
| E1-4 | OPAQUE client+server, bản ghi giả chống dò | P0 | Test vectors RFC 9807; không phân biệt được thời gian |
| E1-5 | Secret Key, Emergency Kit, xác nhận đã lưu | P0 | Nhập lại 3 nhóm ngẫu nhiên |
| E1-6 | Phân cấp khóa, rewrap khi đổi mật khẩu, xoay rootKey/vaultKey | P0 | Payload không đổi khi xoay |
| E1-7 | Review mật mã độc lập (SG1) | P0 | Báo cáo không còn Critical/High |

### E2 — Backend nền tảng (Sprint 2–4)

| ID | Câu chuyện | Ưu tiên | Nghiệm thu |
|---|---|---|---|
| E2-1 | Schema + RLS + role; migration có phê duyệt | P0 | Test bỏ `app.user_id` → không thấy hàng |
| E2-2 | OTP email: HMAC, nonce client, giới hạn | P0 | Dump DB không dùng được OTP |
| E2-3 | Phiên: access/refresh, xoay vòng, phát hiện tái dùng, chữ ký thiết bị | P0 | Reuse → thu hồi họ |
| E2-4 | MFA: TOTP (KMS), WebAuthn, mã dự phòng | P0 | Luồng đăng ký/đăng nhập/mất MFA |
| E2-5 | Giới hạn tần suất (Redis), WAF, egress allowlist | P0 | Test tải và vượt giới hạn |
| E2-6 | Nhật ký allowlist, audit, IP HMAC xoay khóa | P0 | Không có body trong log |
| E2-7 | OpenAPI sinh kiểu; lint hợp đồng trong CI | P0 | CI chặn thay đổi phá vỡ |

### E3 — Két và đồng bộ (Sprint 4–7)

| ID | Câu chuyện | Ưu tiên | Nghiệm thu |
|---|---|---|---|
| E3-1 | CRUD két/mục, `If-Match`, `Idempotency-Key`, `change_seq` trigger | P0 | Test đồng thời không bỏ sót/không trùng |
| E3-2 | `changes` + tombstone + full resync | P0 | Cursor cũ → `fullResyncRequired` |
| E3-3 | Hàng đợi ngoại tuyến, retry có jitter | P0 | Mạng chập chờn không tạo trùng |
| E3-4 | Màn hình xung đột (giữ của tôi/server/cả hai) | P0 | Không mất dữ liệu |
| E3-5 | Phát hiện rollback (`changeSeq` cao nhất) | P0 | Cảnh báo khi server trả số thấp hơn |
| E3-6 | Tìm kiếm cục bộ, bộ sinh mật khẩu | P0 | Không request mạng khi tìm |
| E3-7 | Tệp đính kèm theo chunk | P1 | Chunk bị sửa → từ chối |

### E4 — Thiết bị và khôi phục (Sprint 5–8)

| ID | Câu chuyện | Ưu tiên | Nghiệm thu |
|---|---|---|---|
| E4-1 | Phê duyệt thiết bị bằng QR + chữ ký + SK niêm | P0 | Khóa công khai bị thay → từ chối |
| E4-2 | Đường dự phòng chờ 24 giờ + thông báo + hủy | P0 | Hủy từ thiết bị tin cậy |
| E4-3 | Khôi phục B, C, D, E, F | P0 | Diễn tập từng kịch bản |
| E4-4 | Thu hồi thiết bị/phiên, thông báo, xoay khóa khi nghi ngờ | P0 | Token bị chặn ngay |
| E4-5 | Nhật ký bảo mật cho người dùng (S19) | P0 | Hiển thị đúng sự kiện |

### E5 — Client web và toàn vẹn phát hành (Sprint 4–8)

| ID | Câu chuyện | Ưu tiên | Nghiệm thu |
|---|---|---|---|
| E5-1 | Static host riêng, tài khoản cloud riêng | P0 | Không giữ bí mật API |
| E5-2 | CSP + Trusted Types + SRI; không script bên thứ ba | P0 | Pentest XSS |
| E5-3 | Build tái lập, manifest ký, đăng công khai | P0 | Hai lần build cho cùng hash |
| E5-4 | Giám sát hash bundle từ bên ngoài mỗi 5 phút | P0 | Đổi bundle → cảnh báo ≤ 5 phút |
| E5-5 | Service worker ghim phiên bản | P1 | Cập nhật có thông báo |

### E6 — Client mobile (Sprint 7–11)

| ID | Câu chuyện | Ưu tiên | Nghiệm thu |
|---|---|---|---|
| E6-1 | Keychain/Keystore cho SK, khóa thiết bị P-256 | P0 | Khóa không xuất ra được |
| E6-2 | Sinh trắc học niêm khóa; mất hiệu lực khi đổi sinh trắc | P0 | Kiểm thử trên thiết bị thật |
| E6-3 | Quét/hiển thị QR phê duyệt | P0 | Hoạt động hai chiều |
| E6-4 | Chặn screenshot/app switcher, clipboard tự xóa | P0 | Kiểm thử MASVS |
| E6-5 | Ngoại tuyến, đồng bộ nền | P0 | Chế độ máy bay → xem được |

### E7 — Vận hành và sự cố (Sprint 8–12)

| ID | Câu chuyện | Ưu tiên | Nghiệm thu |
|---|---|---|---|
| E7-1 | Sao lưu DB + PITR; diễn tập khôi phục | P0 | RPO ≤ 1 giờ, RTO ≤ 4 giờ khi diễn tập |
| E7-2 | Canary và cảnh báo truy cập bất thường | P0 | Mô phỏng → cảnh báo |
| E7-3 | Runbook P1–P7, danh bạ trực, kênh dự phòng | P0 | Diễn tập bàn giấy P1, P2 |
| E7-4 | Trang trạng thái và banner sự cố | P1 | Hiển thị khi SEV1 |
| E7-5 | DPIA, chính sách riêng tư, điều khoản, đầu mối bảo vệ dữ liệu | P0 | Duyệt pháp lý |

### E8 — QA và hardening (Sprint 11–12), Beta (Sprint 13)

E8-1 Pentest độc lập web/mobile/API; E8-2 review mật mã lần hai; E8-3 sửa mọi Critical/High; E8-4 diễn tập SEV1 thật (không báo trước); E8-5 beta giới hạn, theo dõi, bug bounty nội bộ.

## 3. Phân bổ sprint (gợi ý)

| Sprint | Trọng tâm | Cổng |
|---|---|---|
| 0–1 | E0, threat model, UX prototype | SG0 |
| 2–3 | E1 (crypto, OPAQUE), E2 khởi đầu | |
| 4 | E1-7 review, E2, E3 khởi đầu, E5 khởi đầu | SG1 |
| 5–6 | E3, E4, E5 (web MVP) | |
| 7–8 | E3 hoàn tất, E4, E6 (mobile) | |
| 9–10 | E6, E7, tích hợp E2E | SG2 |
| 11–12 | E8 (pentest, review, diễn tập, DPIA) | SG3 |
| 13 | Beta có kiểm soát | SG4 |

## 4. Definition of Done

Một câu chuyện chỉ "xong" khi: mã được review (2 người nếu thuộc `crypto`/`auth`/`infra`/workflows); có test tự động; không thêm phụ thuộc chưa qua SCA; không ghi bí mật vào log; chuỗi tiếng Việt đã duyệt; tài liệu liên quan được cập nhật; test bảo mật tương ứng trong TD §13 đạt; pipeline ký/provenance xanh.

## 5. Checklist theo cổng

**SG0:** `an-ninh/Kiem_soat_Chuoi_Cung_ung_va_CICD.md` mục G hoàn tất; ADR chốt; threat model duyệt; lịch kiểm toán độc lập có.
**SG1:** test vectors đạt trên ba nền tảng; OPAQUE hoạt động end-to-end; cryptographer duyệt; NFC/NFD đạt.
**SG2:** E2E web + mobile; khôi phục A–F; BOLA/RLS test xanh; giám sát bundle chạy.
**SG3:** pentest + review mật mã không còn Critical/High; diễn tập SEV1; DPIA; chính sách pháp lý; quy trình tiếp nhận lỗ hổng công khai.
**SG4:** beta ổn định ≥ 2 tuần, không SEV1/SEV2 mở, runbook đã dùng thử.

## 6. Chỉ số theo dõi trong dự án

Tỷ lệ test mật mã đạt; số phát hiện Critical/High mở; MTTD/MTTC khi diễn tập; tỷ lệ phát hành có 2 người duyệt + chữ ký; tỷ lệ người dùng thử nghiệm hoàn tất khôi phục; thời gian mở khóa p95 trên thiết bị tham chiếu.
